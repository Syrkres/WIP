---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner Hostelers
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Rabbit Pub 
ownerName: Andwise Gardumble 
ownerLink: "[[Taverner(Hostelers) - Andwise Gardumble|Andwise Gardumble]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Walpole (Young Adult ) Male who is All Right  
services: 
- Eatery( Poor   quality, Low  costs) 
- Room (Sleeping)( Excellent   quality, Below Average  costs) 
- Common Room (Sleeping)( Excellent   quality, Below Average  costs) 
- Room (Meeting)( Low   quality, Above Average  costs) 
exterior: An two story building with new paint and with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


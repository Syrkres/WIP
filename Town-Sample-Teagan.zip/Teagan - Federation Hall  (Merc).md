---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: Federation Hall 
ownerName: Pearl Brockfoot 
ownerLink: "[[Merc(Merc) - Pearl Brockfoot|Pearl Brockfoot]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Clayton (Teen ) Female who is Dying  
- Atherton (Adult ) Male who is Dying  
services: 
- Mercenary( Good   quality, Above Average  costs) 
- Intimidation( Excellent   quality, Average  costs) 
- Guarding( Low   quality, Above Average  costs) 
exterior: An building with brick siding with a few windows. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: Federation Hall 
ownerName: Jhaumrithe Malsazea 
ownerLink: "[[Merc(Merc) - Jhaumrithe Malsazea|Jhaumrithe Malsazea]]"
ownerRace: Eladrin Elf
apprentices: 
- Landon (Young Adult ) Female who is Well  
- Clifford (Adult ) Male who is Nauseos  
services: 
- Mercenary( Poor   quality, Below Average  costs) 
- Intimidation( Low   quality, Low  costs) 
- Guarding( Excellent   quality, Below Average  costs) 
exterior: An narrow building with new paint and with stoned siding with a few tall windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furniture Maker Artisan
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Something for the house 
ownerName: Ievos Cramlurvirrea 
ownerLink: "[[Furniture Maker(Artisan) - Ievos Cramlurvirrea|Ievos Cramlurvirrea]]"
ownerRace: Wood Elf
apprentices: 
- Bing (Young Adult ) Male who is Dead  
- Carlton (Teen ) Female who is Sick  
services: 
- Artisan( Average   quality, Average  costs) 
- Furniture( Good   quality, Low  costs) 
- Wood Carver( Low   quality, High  costs) 
- Carpentry( Excellent   quality, Average  costs) 
exterior: An tall building with new paint and with brick siding with a few short windows. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


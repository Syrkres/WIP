---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scout Tracker
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: We Lead the Way 
ownerName: Prisca Weedweed 
ownerLink: "[[Scout(Tracker) - Prisca Weedweed|Prisca Weedweed]]"
ownerRace: Stout Halfling
apprentices: 
- Hayes (Young Adult ) Male who is Healthy  
- Westbrook (Young Adult ) Female who is Inured  
services: 
- Tracker( Excellent   quality, High  costs) 
- Scout( Low   quality, Low  costs) 
exterior: An tall building with brick siding with a few short boarded windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


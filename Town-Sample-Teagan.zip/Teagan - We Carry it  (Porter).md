---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Porter 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: We Carry it 
ownerName: Dorri Caebrek 
ownerLink: "[[Porter(Laborer) - Dorri Caebrek|Dorri Caebrek]]"
ownerRace: Hill Dwarf
apprentices: 
- Ainsworth (Teen ) Male who is Well  
services: 
- Laborer( Horrible   quality, Average  costs) 
- Transporter( Good   quality, Above Average  costs) 
exterior: An old long tall building with shingled siding with a few round shuttered windows. The roof is Celing. A Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


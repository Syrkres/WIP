---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scout 
merchantCategory: Tracker
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: We Lead the Way 
ownerName: Birkenhead Saenz 
ownerLink: "[[Scout(Tracker) - Birkenhead Saenz|Birkenhead Saenz]]"
ownerRace: Dragonborn
apprentices: 
- No apprentices
services: 
- Tracker( Average   quality, Low  costs) 
- Scout( Poor   quality, Above Average  costs) 
exterior: An old long tall building with new paint and with planked siding with a few tall windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


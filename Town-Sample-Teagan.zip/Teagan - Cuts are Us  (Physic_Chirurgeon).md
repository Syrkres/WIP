---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Physic/Chirurgeon 
merchantCategory: Professional Specialties
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,ALCHEMIST
title: Cuts are Us 
ownerName: Bilkk Strakeln 
ownerLink: "[[Physic/Chirurgeon(Professional Specialties) - Bilkk Strakeln|Bilkk Strakeln]]"
ownerRace: Hill Dwarf
apprentices: 
- Roscoe (Teen ) Female who is Ailing  
services: 
- Healing( Horrible   quality, High  costs) 
exterior: An old long building with brick siding. The roof is Dome. A Red Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


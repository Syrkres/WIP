---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner 
merchantCategory: Hostelers
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Broken Dark Brown Amulet 
ownerName: Hale Treasure 
ownerLink: "[[Taverner(Hostelers) - Hale Treasure|Hale Treasure]]"
ownerRace: Half-Orc
apprentices: 
- No apprentices
services: 
- Eatery( Average   quality, Above Average  costs) 
- Room (Sleeping)( Excellent   quality, Average  costs) 
- Common Room (Sleeping)( Average   quality, Low  costs) 
- Room (Meeting)( Low   quality, Low  costs) 
exterior: An tall building with new paint and with planked siding with a front short window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


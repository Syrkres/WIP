---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: The Rough Wolf Guild 
ownerName: Grathgor Dirthmitore 
ownerLink: "[[Brigand(Merc) - Grathgor Dirthmitore|Grathgor Dirthmitore]]"
ownerRace: Wood Elf
apprentices: 
- Denholm (Teen ) Female who is Healthy  
- Marlowe (Young Adult ) Male who is Well  
services: 
- Mercenary( Excellent   quality, Average  costs) 
- Enforcement( Poor   quality, High  costs) 
- Intimidation( Horrible   quality, High  costs) 
exterior: An old narrow building with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


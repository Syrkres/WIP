---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Dairy Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The old Store 
ownerName: Pandora Buttonbuck 
ownerLink: "[[Farmer - Dairy(Farmer) - Pandora Buttonbuck|Pandora Buttonbuck]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Snape (Adult ) Male who is Healthy  
services: 
- Farmer( Poor   quality, Low  costs) 
- Milk( Good   quality, Average  costs) 
- Food( Good   quality, Below Average  costs) 
exterior: An building with brick siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


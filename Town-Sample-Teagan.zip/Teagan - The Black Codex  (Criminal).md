---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Black Codex 
ownerName: Vaervenshalice Norreatear 
ownerLink: "[[Crime Lord(Criminal) - Vaervenshalice Norreatear|Vaervenshalice Norreatear]]"
ownerRace: Elf
apprentices: 
- Appleton (Young Adult ) Female who is Fine  
services: 
- Blackmarket( Good   quality, High  costs) 
- Merchant( Low   quality, Low  costs) 
- Transfer of Goods( Horrible   quality, Average  costs) 
exterior: An long two story building with stoned siding with a front short shuttered window that has a carved sign hanging to the side with the merchants name. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


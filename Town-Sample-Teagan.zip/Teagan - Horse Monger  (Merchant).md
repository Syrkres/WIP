---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Horse Monger 
ownerName: Weld Mccormick 
ownerLink: "[[Horse Trader(Merchant) - Weld Mccormick|Weld Mccormick]]"
ownerRace: Half-Orc
apprentices: 
- No apprentices
services: 
- Horse Trading( Poor   quality, Low  costs) 
- Trader( Excellent   quality, Average  costs) 
- Horse Breeding( Good   quality, Low  costs) 
exterior: An new narrow building with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


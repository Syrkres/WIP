---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hostelers
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The old Store 
ownerName: Marmadoc Fairbuck 
ownerLink: "[[Brothel Keeper(Hostelers) - Marmadoc Fairbuck|Marmadoc Fairbuck]]"
ownerRace: Stout Halfling
apprentices: 
- Shelley (Adult ) Male who is Maimed  
- Rodney (Teen ) Female who is Ailing  
services: 
- Room (Pleasure)( Good   quality, Low  costs) 
- Common Room (Sleeping)( Poor   quality, High  costs) 
- Room (Meeting)( Low   quality, Below Average  costs) 
exterior: An new building with stoned siding with a few short shuttered windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


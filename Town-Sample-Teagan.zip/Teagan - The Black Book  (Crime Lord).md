---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Black Book 
ownerName: Polo Goldgee 
ownerLink: "[[Crime Lord(Criminal) - Polo Goldgee|Polo Goldgee]]"
ownerRace: Stout Halfling
apprentices: 
- Elton (Teen ) Female who is Unwell  
- Graeme (Mature Adult ) Male who is Well  
services: 
- Blackmarket( Good   quality, Above Average  costs) 
- Merchant( Good   quality, Average  costs) 
- Transfer of Goods( Excellent   quality, Low  costs) 
exterior: An new long tall building with new paint and with planked siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


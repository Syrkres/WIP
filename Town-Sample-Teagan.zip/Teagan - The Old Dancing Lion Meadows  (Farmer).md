---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Old Dancing Lion Meadows 
ownerName: Myrtle Clodman 
ownerLink: "[[Farmer - Cabbage(Farmer) - Myrtle Clodman|Myrtle Clodman]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Graeme (Young Adult ) Male who is Unwell  
services: 
- Farmer( Average   quality, High  costs) 
- Food( Low   quality, High  costs) 
exterior: An new narrow building with new paint and with stoned siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


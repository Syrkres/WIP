---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pirate 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Peg-leg Tavern 
ownerName: Bradly Gabb 
ownerLink: "[[Pirate(Merc) - Bradly Gabb|Bradly Gabb]]"
ownerRace: Khenra
apprentices: 
- Ainsworth (Child ) Female who is Well  
services: 
- Mercenary( Poor   quality, Below Average  costs) 
- Intimidation( Good   quality, Average  costs) 
- Shipping( Excellent   quality, Above Average  costs) 
- Guarding( Good   quality, Low  costs) 
exterior: An old narrow building with faded paint and with stoned siding with a front shuttered window that has a sign hanging above with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


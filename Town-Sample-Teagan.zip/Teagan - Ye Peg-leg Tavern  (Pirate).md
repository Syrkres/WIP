---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pirate 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Peg-leg Tavern 
ownerName: Pandora Weedbody 
ownerLink: "[[Pirate(Merc) - Pandora Weedbody|Pandora Weedbody]]"
ownerRace: Stout Halfling
apprentices: 
- Webley (Teen ) Male who is Healthy  
services: 
- Mercenary( Low   quality, Above Average  costs) 
- Intimidation( Average   quality, Below Average  costs) 
- Shipping( Poor   quality, Average  costs) 
- Guarding( Good   quality, Average  costs) 
exterior: An two story building with planked siding with a few short windows. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


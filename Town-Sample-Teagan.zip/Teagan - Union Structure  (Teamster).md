---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Union Structure 
ownerName: Cornelia Gardfoot 
ownerLink: "[[Teamster(Laborer) - Cornelia Gardfoot|Cornelia Gardfoot]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Beverly (Young Adult ) Male who is Fine  
- Eastaughffe (Teen ) Female who is Fine  
services: 
- Laborer( Low   quality, Above Average  costs) 
- Teamster( Horrible   quality, Low  costs) 
exterior: An new long building with stoned siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Tall Indian Corn Fields 
ownerName: Venali Lonmumlylth 
ownerLink: "[[Farmer - Corn(Farmer) - Venali Lonmumlylth|Venali Lonmumlylth]]"
ownerRace: High  Elf
apprentices: 
- Sheldon (Teen ) Female who is Deceased  
- Bentley (Teen ) Male who is Fine  
services: 
- Farmer( Poor   quality, Average  costs) 
- Food( Excellent   quality, Below Average  costs) 
exterior: An new narrow building with faded paint and with shingled siding with a few windows. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


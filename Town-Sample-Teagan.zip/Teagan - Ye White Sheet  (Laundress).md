---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laundress 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye White Sheet 
ownerName: Landon Harvey 
ownerLink: "[[Laundress(Laborer) - Landon Harvey|Landon Harvey]]"
ownerRace: Kor
apprentices: 
- Shelby (Teen ) Female who is Under the weather  
services: 
- Laborer( Excellent   quality, Below Average  costs) 
- Cleaning( Excellent   quality, Low  costs) 
exterior: An building with brick siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laundress 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye White Sheet 
ownerName: Skalanis Tamlimentannia 
ownerLink: "[[Laundress(Laborer) - Skalanis Tamlimentannia|Skalanis Tamlimentannia]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Laborer( Excellent   quality, Low  costs) 
- Cleaning( Good   quality, High  costs) 
exterior: An narrow one story building with new paint and with shingled siding with a few windows. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Physic/Chirurgeon 
merchantCategory: Professional Specialties
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,ALCHEMIST
title: We repair You 
ownerName: Hornsby Nairn 
ownerLink: "[[Physic/Chirurgeon(Professional Specialties) - Hornsby Nairn|Hornsby Nairn]]"
ownerRace: Half-Orc
apprentices: 
- No apprentices
services: 
- Healing( Horrible   quality, Average  costs) 
exterior: An two story building with shingled siding with a missing round window. The roof is Celing. A Maple shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


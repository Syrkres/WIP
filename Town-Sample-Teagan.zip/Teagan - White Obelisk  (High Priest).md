---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Priest 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: White Obelisk 
ownerName: Eltargrim Hubugonanea 
ownerLink: "[[High Priest(Clergy) - Eltargrim Hubugonanea|Eltargrim Hubugonanea]]"
ownerRace: Tajuru Nation Elf
apprentices: 
- Winthrop (Adult ) Female who is Well  
- Prescott (Teen ) Male who is Healthy  
services: 
- Clergy( Low   quality, Average  costs) 
- Scroll Crafting( Excellent   quality, High  costs) 
- Potion Crafting( Excellent   quality, Below Average  costs) 
- Spell Research( Good   quality, Average  costs) 
- Healing( Poor   quality, High  costs) 
exterior: An two story building with planked siding with a missing tall window. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Priest 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: White Obelisk 
ownerName: Simgari Rumnaheim 
ownerLink: "[[High Priest(Clergy) - Simgari Rumnaheim|Simgari Rumnaheim]]"
ownerRace: Hill Dwarf
apprentices: 
- Wesley (Child ) Male who is Healthy  
services: 
- Clergy( Horrible   quality, Below Average  costs) 
- Scroll Crafting( Horrible   quality, Below Average  costs) 
- Potion Crafting( Low   quality, Low  costs) 
- Spell Research( Low   quality, Average  costs) 
- Healing( Low   quality, High  costs) 
exterior: An two story building with new paint and with shingled siding with a few short shuttered windows. The roof is Roof. A Cherry shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: The Gecko Guild 
ownerName: Orlpar Krargolannia 
ownerLink: "[[Brigand(Merc) - Orlpar Krargolannia|Orlpar Krargolannia]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Mercenary( Average   quality, Above Average  costs) 
- Enforcement( Excellent   quality, Average  costs) 
- Intimidation( Good   quality, Above Average  costs) 
exterior: An building with planked siding with a front tall boarded window that has a sign hanging above with the merchants name. The roof is Roof. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


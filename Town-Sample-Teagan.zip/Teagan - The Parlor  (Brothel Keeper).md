---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hostelers
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Parlor 
ownerName: Alauthshaee Perleltlithar 
ownerLink: "[[Brothel Keeper(Hostelers) - Alauthshaee Perleltlithar|Alauthshaee Perleltlithar]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Room (Pleasure)( Poor   quality, Average  costs) 
- Common Room (Sleeping)( Excellent   quality, Below Average  costs) 
- Room (Meeting)( Low   quality, High  costs) 
exterior: An building with new paint and with shingled siding. The roof is Roof. A Hickory pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


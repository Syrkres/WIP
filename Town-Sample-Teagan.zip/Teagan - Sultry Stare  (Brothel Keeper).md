---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hostelers
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Sultry Stare 
ownerName: Barton Schwartz 
ownerLink: "[[Brothel Keeper(Hostelers) - Barton Schwartz|Barton Schwartz]]"
ownerRace: Half-Orc
apprentices: 
- Rutherford (Teen ) Female who is Well  
services: 
- Room (Pleasure)( Good   quality, Above Average  costs) 
- Common Room (Sleeping)( Horrible   quality, Below Average  costs) 
- Room (Meeting)( Excellent   quality, Average  costs) 
exterior: An old long two story building with faded paint and with stoned siding. The roof is Celing. A Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


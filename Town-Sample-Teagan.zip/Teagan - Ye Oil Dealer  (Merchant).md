---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Oil Dealer 
ownerName: Ryley Mudge 
ownerLink: "[[Oil Trader(Merchant) - Ryley Mudge|Ryley Mudge]]"
ownerRace: Human
apprentices: 
- Hayley (Teen ) Female who is Healthy  
services: 
- Merchant( Good   quality, High  costs) 
- Oil Trader( Poor   quality, Below Average  costs) 
exterior: An old narrow building with new paint and with brick siding with a front round window that has a carved sign hanging to the side with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


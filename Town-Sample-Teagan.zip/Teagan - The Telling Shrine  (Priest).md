---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Priest 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: The Telling Shrine 
ownerName: Jhuvik Bulruettln 
ownerLink: "[[Priest(Clergy) - Jhuvik Bulruettln|Jhuvik Bulruettln]]"
ownerRace: Wood Elf
apprentices: 
- Compton (Teen ) Female who is Fit  
services: 
- Clergy( Horrible   quality, Above Average  costs) 
- Religion( Low   quality, Average  costs) 
- Healing( Poor   quality, High  costs) 
exterior: An building with planked siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


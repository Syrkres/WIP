---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Fat Pigeon Hill Nursery 
ownerName: Cotman Rumward 
ownerLink: "[[Farmer - Wheat(Farmer) - Cotman Rumward|Cotman Rumward]]"
ownerRace: Ghostwise Halfling
apprentices: 
- No apprentices
services: 
- Farmer( Excellent   quality, Below Average  costs) 
- Food( Low   quality, Low  costs) 
exterior: An old building with new paint and with planked siding. The roof is Roof. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


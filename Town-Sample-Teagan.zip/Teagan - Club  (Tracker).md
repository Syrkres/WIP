---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tracker 
merchantCategory: Tracker
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Club 
ownerName: Clapham Petcher 
ownerLink: "[[Tracker(Tracker) - Clapham Petcher|Clapham Petcher]]"
ownerRace: Aasimar)
apprentices: 
- No apprentices
services: 
- Tracker( Average   quality, High  costs) 
- Hunter( Good   quality, Low  costs) 
exterior: An old tall building with shingled siding with a front window that has a painted sign hanging above with the merchants name. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


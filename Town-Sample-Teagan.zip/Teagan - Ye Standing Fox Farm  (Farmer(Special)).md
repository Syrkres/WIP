---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Standing Fox Farm 
ownerName: Myrddin Zaiganelrvis 
ownerLink: "[[Farmer(Special)(Farmer) - Myrddin Zaiganelrvis|Myrddin Zaiganelrvis]]"
ownerRace: Wood Elf
apprentices: 
- Morley (Young Adult ) Male who is Wounded  
- Hayes (Teen ) Female who is All Right  
services: 
- Farmer( Average   quality, Above Average  costs) 
- Food( Excellent   quality, High  costs) 
- Herding( Average   quality, Average  costs) 
exterior: An long tall building with new paint and with brick siding. The roof is House. A Yellow Birch shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


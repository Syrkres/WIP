---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tracker 
merchantCategory: Tracker
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Lodge 
ownerName: Shammath Brulgumriatear 
ownerLink: "[[Tracker(Tracker) - Shammath Brulgumriatear|Shammath Brulgumriatear]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Tracker( Average   quality, Below Average  costs) 
- Hunter( Horrible   quality, Average  costs) 
exterior: An old tall building with new paint and with shingled siding. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


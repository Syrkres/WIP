---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: Group Hall 
ownerName: Pywaln Phimodotylar 
ownerLink: "[[Merc(Merc) - Pywaln Phimodotylar|Pywaln Phimodotylar]]"
ownerRace: High  Elf
apprentices: 
- Emsworth (Child ) Male who is Not oneself  
- Dryden (Young Adult ) Male who is All Right  
services: 
- Mercenary( Average   quality, Low  costs) 
- Intimidation( Poor   quality, Low  costs) 
- Guarding( Poor   quality, Below Average  costs) 
exterior: An old building with new paint and with shingled siding with a front boarded window that has a sign hanging above with the merchants name. The roof is House. A Oak shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


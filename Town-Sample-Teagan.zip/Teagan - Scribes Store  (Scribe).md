---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe 
merchantCategory: Professional Specialties
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,ALCHEMIST
title: Scribes Store 
ownerName: Burton Dring 
ownerLink: "[[Scribe(Professional Specialties) - Burton Dring|Burton Dring]]"
ownerRace: Fire Genasi
apprentices: 
- Benson (Child ) Female who is All Right  
services: 
- Research( Poor   quality, High  costs) 
- Scribe( Average   quality, Low  costs) 
exterior: An new long building with faded paint and with stoned siding with a front tall window that has a carved sign hanging to the side with the merchants name. The roof is Dome. A Cherry shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


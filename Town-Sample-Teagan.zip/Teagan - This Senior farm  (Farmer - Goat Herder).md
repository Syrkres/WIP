---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: This Senior farm 
ownerName: Zandro Ailonettln 
ownerLink: "[[Farmer - Goat Herder(Farmer) - Zandro Ailonettln|Zandro Ailonettln]]"
ownerRace: Elf
apprentices: 
- Hackney (Child ) Male who is Fit  
- Yardley (Young Adult ) Female who is Unwell  
services: 
- Farmer( Average   quality, Below Average  costs) 
- Food( Poor   quality, Above Average  costs) 
- Herding( Average   quality, High  costs) 
exterior: An old building with new paint and with planked siding with a missing round window. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


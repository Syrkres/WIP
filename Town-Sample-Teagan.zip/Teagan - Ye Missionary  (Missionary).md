---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Missionary 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: Ye Missionary 
ownerName: Snape Moggs 
ownerLink: "[[Missionary(Clergy) - Snape Moggs|Snape Moggs]]"
ownerRace: Fire Genasi
apprentices: 
- Branson (Young Adult ) Male who is Incapacitaed  
services: 
- Clergy( Average   quality, Average  costs) 
- Religion( Good   quality, Average  costs) 
- Remedies( Horrible   quality, Below Average  costs) 
exterior: An tall building with faded paint and with shingled siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


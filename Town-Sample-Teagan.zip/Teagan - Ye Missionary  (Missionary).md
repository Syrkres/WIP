---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Missionary 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: Ye Missionary 
ownerName: Habaccuc Greenlock 
ownerLink: "[[Missionary(Clergy) - Habaccuc Greenlock|Habaccuc Greenlock]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Rylan (Young Adult ) Male who is Fit  
services: 
- Clergy( Good   quality, Above Average  costs) 
- Religion( Poor   quality, Below Average  costs) 
- Remedies( Poor   quality, Above Average  costs) 
exterior: An long one story building with faded paint and with shingled siding with a few short windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Used Garment Trader 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Clothes Dealer 
ownerName: Lindsey Moore 
ownerLink: "[[Used Garment Trader(Garment Trade) - Lindsey Moore|Lindsey Moore]]"
ownerRace: Water Genasi
apprentices: 
- Hartford (Young Adult ) Female who is Healthy  
- Sheldon (Teen ) Male who is Not oneself  
services: 
- Garment Trade( Horrible   quality, Below Average  costs) 
- Trader( Good   quality, Low  costs) 
exterior: An old long building with faded paint and with planked siding. The roof is Roof. A Yellow Birch pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


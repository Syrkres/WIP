---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thief Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Grog Eagle 
ownerName: Otho Loampipe 
ownerLink: "[[Thief(Criminal) - Otho Loampipe|Otho Loampipe]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Read (Teen ) Female who is Out of sorts  
- Merton (Young Adult ) Female who is Fine  
services: 
- Criminal( Excellent   quality, Below Average  costs) 
- Deception( Horrible   quality, Average  costs) 
exterior: An tall building with brick siding with a front shuttered window that has a carved sign hanging to the side with the merchants name. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


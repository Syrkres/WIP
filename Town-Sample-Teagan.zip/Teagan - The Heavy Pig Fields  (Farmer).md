---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Heavy Pig Fields 
ownerName: Isengrim Bracefoot 
ownerLink: "[[Farmer - Pig Herder(Farmer) - Isengrim Bracefoot|Isengrim Bracefoot]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Wentworth (Adult ) Male who is All Right  
- Beckwith (Teen ) Male who is Healthy  
services: 
- Farmer( Good   quality, Average  costs) 
- Food( Excellent   quality, Below Average  costs) 
- Herding( Horrible   quality, High  costs) 
exterior: An building with faded paint and with shingled siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


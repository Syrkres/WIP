---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Guard 
merchantCategory: Guard
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,JAIL
title: Jail 
ownerName: Langdon Beard 
ownerLink: "[[Guard(Guard) - Langdon Beard|Langdon Beard]]"
ownerRace: Half-Elf
apprentices: 
- Pickering (Young Adult ) Male who is Ill  
services: 
- Guarding( Horrible   quality, Average  costs) 
- Intimidation( Poor   quality, Low  costs) 
exterior: An one story building with stoned siding with a missing tall window. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


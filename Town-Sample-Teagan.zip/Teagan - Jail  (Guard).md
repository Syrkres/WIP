---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Guard 
merchantCategory: Guard
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,JAIL
title: Jail 
ownerName: Lindsay Roche 
ownerLink: "[[Guard(Guard) - Lindsay Roche|Lindsay Roche]]"
ownerRace: Kor
apprentices: 
- Benson (Young Adult ) Female who is Healthy  
- Snowdon (Teen ) Female who is Healthy  
services: 
- Guarding( Poor   quality, Below Average  costs) 
- Intimidation( Average   quality, High  costs) 
exterior: An building with brick siding. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


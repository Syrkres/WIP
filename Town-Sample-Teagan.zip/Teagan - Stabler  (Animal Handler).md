---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Stabler Animal Handler
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Stabler 
ownerName: Jago Bracehole 
ownerLink: "[[Stabler(Animal Handler) - Jago Bracehole|Jago Bracehole]]"
ownerRace: Stout Halfling
apprentices: 
- Roscoe (Teen ) Male who is Unwell  
- Royston (Young Adult ) Female who is Healthy  
services: 
- Animal Handler( Poor   quality, Low  costs) 
- Stabler( Low   quality, Low  costs) 
exterior: An one story building with stoned siding with a few shuttered windows. The roof is Canopy. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


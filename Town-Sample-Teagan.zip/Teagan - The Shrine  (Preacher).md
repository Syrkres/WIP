---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Preacher 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: The Shrine 
ownerName: Hayes Polkinghorne 
ownerLink: "[[Preacher(Clergy) - Hayes Polkinghorne|Hayes Polkinghorne]]"
ownerRace: Amonkhet Human
apprentices: 
- No apprentices
services: 
- Clergy( Average   quality, Below Average  costs) 
- Religion( Excellent   quality, Average  costs) 
exterior: An building with new paint and with planked siding with a few windows. The roof is Canopy. A Hickory shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Preacher 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: The Shrine 
ownerName: Elfstan Loampen 
ownerLink: "[[Preacher(Clergy) - Elfstan Loampen|Elfstan Loampen]]"
ownerRace: Stout Halfling
apprentices: 
- Wentworth (Young Adult ) Male who is Fine  
- Clapham (Mature Adult ) Male who is Healthy  
services: 
- Clergy( Horrible   quality, Above Average  costs) 
- Religion( Low   quality, Average  costs) 
exterior: An long tall building with new paint and with shingled siding. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


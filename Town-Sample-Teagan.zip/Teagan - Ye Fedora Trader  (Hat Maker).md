---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Fedora Trader 
ownerName: Ferumbras Bulgerogers 
ownerLink: "[[Hat Maker(Garment Trade) - Ferumbras Bulgerogers|Ferumbras Bulgerogers]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Rodney (Young Adult ) Male who is Unwell  
- Alston (Young Adult ) Female who is Healthy  
services: 
- Garment Trade( Low   quality, Below Average  costs) 
- Hat Maker( Low   quality, Below Average  costs) 
exterior: An old one story building with faded paint and with brick siding with a front tall broken window that has a carved sign hanging to the side with the merchants name. The roof is Dome. A Hickory pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


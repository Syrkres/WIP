---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Heavy Owl Hill Nursery 
ownerName: Jastra Phimodoarnith 
ownerLink: "[[Farmer - Cattle Herder(Farmer) - Jastra Phimodoarnith|Jastra Phimodoarnith]]"
ownerRace: Elf
apprentices: 
- Emsworth (Young Adult ) Male who is Fine  
services: 
- Farmer( Average   quality, High  costs) 
- Food( Poor   quality, High  costs) 
exterior: An old building with faded paint and with brick siding. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


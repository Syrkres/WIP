---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,EXOTIC ARTISAN
title: The new The Earing   
ownerName: Falco Gooldfoot 
ownerLink: "[[Antiquities(Merchant) - Falco Gooldfoot|Falco Gooldfoot]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Ashton (Young Adult ) Male who is Fit  
services: 
- Merchant( Poor   quality, Average  costs) 
- Item Research( Poor   quality, Above Average  costs) 
exterior: An new long building with brick siding with a few round boarded windows. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mayor 
merchantCategory: Elected Official
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Town Hall 
ownerName: Yghiilra Lonmumghymn 
ownerLink: "[[Mayor(Elected Official) - Yghiilra Lonmumghymn|Yghiilra Lonmumghymn]]"
ownerRace: Elf
apprentices: 
- Wheatley (Young Adult ) Female who is Healthy  
services: 
- Elected Official( Average   quality, Below Average  costs) 
- Diplomacy( Average   quality, Below Average  costs) 
exterior: An new long two story building with shingled siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


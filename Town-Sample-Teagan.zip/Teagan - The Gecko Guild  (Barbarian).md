---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,STABLE
title: The Gecko Guild 
ownerName: Briffo Rootburrow 
ownerLink: "[[Barbarian(Merc) - Briffo Rootburrow|Briffo Rootburrow]]"
ownerRace: Lightfoot Halfling
apprentices: 
- No apprentices
services: 
- Mercenary( Excellent   quality, Low  costs) 
- Tracking( Excellent   quality, Below Average  costs) 
exterior: An one story building with stoned siding with a missing tall window. The roof is Celing. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


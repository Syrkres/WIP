---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: Shrine of the Plantation 
ownerName: Aurae Arkeneaarnith 
ownerLink: "[[Cleric(Clergy) - Aurae Arkeneaarnith|Aurae Arkeneaarnith]]"
ownerRace: Elf
apprentices: 
- Dalton (Child ) Male who is Fit  
services: 
- Clergy( Average   quality, Low  costs) 
- Religion( Poor   quality, Low  costs) 
- House of Worship( Average   quality, Below Average  costs) 
- Curse Removal( Excellent   quality, High  costs) 
- Spell Research( Good   quality, Above Average  costs) 
- Healing( Horrible   quality, Low  costs) 
- Potions( Average   quality, Low  costs) 
exterior: An tall building with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


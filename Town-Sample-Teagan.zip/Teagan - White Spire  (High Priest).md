---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Priest 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: White Spire 
ownerName: Drogo Dugsgirdle 
ownerLink: "[[High Priest(Clergy) - Drogo Dugsgirdle|Drogo Dugsgirdle]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Soames (Young Adult ) Female who is Fit  
services: 
- Clergy( Horrible   quality, Below Average  costs) 
- Scroll Crafting( Poor   quality, Above Average  costs) 
- Potion Crafting( Horrible   quality, Average  costs) 
- Spell Research( Low   quality, Low  costs) 
- Healing( Poor   quality, Above Average  costs) 
exterior: An old tall building with shingled siding. The roof is House. A Red Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


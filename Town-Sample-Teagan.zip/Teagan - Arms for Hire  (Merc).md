---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: Arms for Hire 
ownerName: Pippin Oakhill 
ownerLink: "[[Brigand(Merc) - Pippin Oakhill|Pippin Oakhill]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Whitby (Teen ) Female who is Impaired  
services: 
- Mercenary( Low   quality, High  costs) 
- Enforcement( Good   quality, High  costs) 
- Intimidation( Poor   quality, Low  costs) 
exterior: An new two story building with faded paint and with planked siding. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


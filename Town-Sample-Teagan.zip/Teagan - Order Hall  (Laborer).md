---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Order Hall 
ownerName: Berkeley Gunn 
ownerLink: "[[Laborer(Laborer) - Berkeley Gunn|Berkeley Gunn]]"
ownerRace: Half-Elf
apprentices: 
- Underhill (Teen ) Female who is Fit as a fiddle  
services: 
- Laborer( Excellent   quality, Average  costs) 
exterior: An new narrow building with brick siding. The roof is Canopy. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner 
merchantCategory: Hostelers
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Boar Inn 
ownerName: Primrose Teaman 
ownerLink: "[[Taverner(Hostelers) - Primrose Teaman|Primrose Teaman]]"
ownerRace: Ghostwise Halfling
apprentices: 
- No apprentices
services: 
- Eatery( Average   quality, Average  costs) 
- Room (Sleeping)( Poor   quality, Below Average  costs) 
- Common Room (Sleeping)( Average   quality, High  costs) 
- Room (Meeting)( Low   quality, High  costs) 
exterior: An narrow two story building with new paint and with planked siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Pawn Reseller 
ownerName: Ogden Bogue 
ownerLink: "[[Crook(Criminal) - Ogden Bogue|Ogden Bogue]]"
ownerRace: Scourge Aasimar
apprentices: 
- Payton (Adult ) Male who is Sick  
services: 
- Criminal( Low   quality, High  costs) 
- Deception( Excellent   quality, Below Average  costs) 
- Theft( Horrible   quality, Above Average  costs) 
exterior: An old building with planked siding with a missing short window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


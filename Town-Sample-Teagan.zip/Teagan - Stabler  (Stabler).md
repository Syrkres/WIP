---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Stabler 
merchantCategory: Animal Handler
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Stabler 
ownerName: Cromwell Gosden 
ownerLink: "[[Stabler(Animal Handler) - Cromwell Gosden|Cromwell Gosden]]"
ownerRace: Human
apprentices: 
- Cholmondeley (Mature Adult ) Female who is Fine  
- Tyndall (Teen ) Female who is Sick  
services: 
- Animal Handler( Horrible   quality, Below Average  costs) 
- Stabler( Excellent   quality, Below Average  costs) 
exterior: An new two story building with new paint and with shingled siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


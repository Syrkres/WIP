---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Stabler 
merchantCategory: Animal Handler
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Stabler 
ownerName: Leighton Norton 
ownerLink: "[[Stabler(Animal Handler) - Leighton Norton|Leighton Norton]]"
ownerRace: Human Variant
apprentices: 
- Pickering (Young Adult ) Female who is Fine  
services: 
- Animal Handler( Horrible   quality, Below Average  costs) 
- Stabler( Horrible   quality, Below Average  costs) 
exterior: An old narrow tall building with new paint and with planked siding with a front tall window that has a carved sign hanging to the side with the merchants name. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Missionary Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: The Missionary 
ownerName: Bosco Smalliffer 
ownerLink: "[[Missionary(Clergy) - Bosco Smalliffer|Bosco Smalliffer]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Wesley (Mature Adult ) Male who is Under the weather  
services: 
- Clergy( Poor   quality, High  costs) 
- Religion( Horrible   quality, Below Average  costs) 
- Remedies( Good   quality, Below Average  costs) 
exterior: An building with shingled siding with a few windows. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


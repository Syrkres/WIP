---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: Shrine of the Learning 
ownerName: Sutherland Madden 
ownerLink: "[[Cleric(Clergy) - Sutherland Madden|Sutherland Madden]]"
ownerRace: Human
apprentices: 
- No apprentices
services: 
- Clergy( Good   quality, Above Average  costs) 
- Religion( Average   quality, Below Average  costs) 
- House of Worship( Low   quality, Above Average  costs) 
- Curse Removal( Poor   quality, High  costs) 
- Spell Research( Average   quality, High  costs) 
- Healing( Excellent   quality, Average  costs) 
- Potions( Poor   quality, Below Average  costs) 
exterior: An one story building with new paint and with brick siding with a missing window. The roof is Roof. A Hickory shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


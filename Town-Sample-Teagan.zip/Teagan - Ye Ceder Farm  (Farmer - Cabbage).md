---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Ceder Farm 
ownerName: Poppy Gaukhill 
ownerLink: "[[Farmer - Cabbage(Farmer) - Poppy Gaukhill|Poppy Gaukhill]]"
ownerRace: Stout Halfling
apprentices: 
- Altham (Adult ) Male who is All Right  
- Compton (Young Adult ) Male who is Nauseos  
services: 
- Farmer( Horrible   quality, Above Average  costs) 
- Food( Horrible   quality, Above Average  costs) 
exterior: An tall building with faded paint and with stoned siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Pawn Market Stall 
ownerName: Bargrima Trollbleeder 
ownerLink: "[[Crook(Criminal) - Bargrima Trollbleeder|Bargrima Trollbleeder]]"
ownerRace: Hill Dwarf
apprentices: 
- Ainsworth (Child ) Female who is Healthy as a horse  
services: 
- Criminal( Poor   quality, Below Average  costs) 
- Deception( Low   quality, Low  costs) 
- Theft( Excellent   quality, High  costs) 
exterior: An old building with stoned siding with a few broken windows. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


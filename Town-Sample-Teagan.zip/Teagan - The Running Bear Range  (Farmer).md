---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Running Bear Range 
ownerName: Kindroth Devonkaleplith 
ownerLink: "[[Farmer - Cabbage(Farmer) - Kindroth Devonkaleplith|Kindroth Devonkaleplith]]"
ownerRace: High  Elf
apprentices: 
- Hackney (Young Adult ) Female who is All Right  
- Morley (Young Adult ) Male who is Fit  
services: 
- Farmer( Good   quality, Low  costs) 
- Food( Average   quality, Below Average  costs) 
exterior: An building with new paint and with brick siding with a front tall window that has a sign hanging above with the merchants name. The roof is Roof. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


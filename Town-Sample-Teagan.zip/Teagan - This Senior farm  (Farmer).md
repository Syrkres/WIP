---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: This Senior farm 
ownerName: Blythe Galloway 
ownerLink: "[[Farmer - Cattle Herder(Farmer) - Blythe Galloway|Blythe Galloway]]"
ownerRace: Human
apprentices: 
- Ridley (Teen ) Male who is Fit  
- Underhill (Child ) Female who is Healthy  
services: 
- Farmer( Low   quality, High  costs) 
- Food( Poor   quality, Below Average  costs) 
exterior: An old building with faded paint and with brick siding with a missing window. The roof is House. A Pine shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker 
merchantCategory: Craftsman
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Platinum Kettle 
ownerName: Cotton Stanford 
ownerLink: "[[Kettle Maker(Craftsman) - Cotton Stanford|Cotton Stanford]]"
ownerRace: Half-Elf
apprentices: 
- Prescott (Young Adult ) Male who is All Right  
- Hartford (Teen ) Female who is All Right  
services: 
- Craftsman( Poor   quality, Above Average  costs) 
- Merchant( Good   quality, Above Average  costs) 
exterior: An building with planked siding. The roof is Dome. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


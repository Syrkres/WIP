---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sailor Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Narrow Captain Pub 
ownerName: Maelyrra Hunithatear 
ownerLink: "[[Sailor(Merc) - Maelyrra Hunithatear|Maelyrra Hunithatear]]"
ownerRace: High  Elf
apprentices: 
- Bentham (Young Adult ) Female who is Healthy  
services: 
- Mercenary( Horrible   quality, Above Average  costs) 
- Sailor( Average   quality, Above Average  costs) 
- Thug( Average   quality, Below Average  costs) 
exterior: An new long one story building with new paint and with planked siding with a few short broken windows. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


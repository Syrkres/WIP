---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Priest Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: White Spire 
ownerName: Sherwood Purslove 
ownerLink: "[[High Priest(Clergy) - Sherwood Purslove|Sherwood Purslove]]"
ownerRace: Human
apprentices: 
- Lancaster (Young Adult ) Male who is Fit  
- Clive (Young Adult ) Female who is Healthy  
services: 
- Clergy( Average   quality, Low  costs) 
- Scroll Crafting( Poor   quality, High  costs) 
- Potion Crafting( Poor   quality, Above Average  costs) 
- Spell Research( Horrible   quality, Average  costs) 
- Healing( Low   quality, Average  costs) 
exterior: An old narrow building with new paint and with shingled siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Bowler Trader 
ownerName: Upton Wann 
ownerLink: "[[Hat Maker(Garment Trade) - Upton Wann|Upton Wann]]"
ownerRace: Human
apprentices: 
- No apprentices
services: 
- Garment Trade( Excellent   quality, Above Average  costs) 
- Hat Maker( Poor   quality, Below Average  costs) 
exterior: An building with stoned siding with a few short broken windows. The roof is Roof. A Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thug Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Grog Hawk 
ownerName: Chica Brockhill 
ownerLink: "[[Thug(Criminal) - Chica Brockhill|Chica Brockhill]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Kelsey (Teen ) Male who is Healthy  
services: 
- Criminal( Average   quality, High  costs) 
- Deception( Horrible   quality, Average  costs) 
- Guarding( Good   quality, Above Average  costs) 
exterior: An new narrow two story building with faded paint and with planked siding. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: SellSpell 
merchantCategory: Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,ALCHEMIST
title: Casters Shop 
ownerName: Nlaea Kralseberdlues 
ownerLink: "[[SellSpell(Sage) - Nlaea Kralseberdlues|Nlaea Kralseberdlues]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Sage( Average   quality, Below Average  costs) 
- Spellcraft( Poor   quality, Low  costs) 
- Spell Research( Average   quality, Low  costs) 
- Spell Casting( Average   quality, Above Average  costs) 
exterior: An narrow tall building with new paint and with planked siding with a front window that has a sign hanging above with the merchants name. The roof is Roof. A Elm shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


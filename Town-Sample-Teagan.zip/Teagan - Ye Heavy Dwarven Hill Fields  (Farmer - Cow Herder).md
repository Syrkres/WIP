---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Heavy Dwarven Hill Fields 
ownerName: Paulorin Zaigantlithar 
ownerLink: "[[Farmer - Cow Herder(Farmer) - Paulorin Zaigantlithar|Paulorin Zaigantlithar]]"
ownerRace: Wood Elf
apprentices: 
- Clifton (Teen ) Female who is Unwell  
- Trollope (Adult ) Female who is All Right  
services: 
- Farmer( Horrible   quality, Above Average  costs) 
- Food( Horrible   quality, Above Average  costs) 
exterior: An old building with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


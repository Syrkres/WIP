---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furrier Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Warmest Fur 
ownerName: Grossman Hayville 
ownerLink: "[[Furrier(Garment Trade) - Grossman Hayville|Grossman Hayville]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Shirley (Teen ) Female who is At death's door  
services: 
- Garment Trade( Good   quality, High  costs) 
- Fur Processing( Horrible   quality, Low  costs) 
exterior: An two story building with faded paint and with brick siding with a front shuttered window that has a painted sign hanging above with the merchants name. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


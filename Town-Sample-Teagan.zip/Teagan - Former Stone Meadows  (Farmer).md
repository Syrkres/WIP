---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Former Stone Meadows 
ownerName: Akhelbhen Salinsithek 
ownerLink: "[[Farmer(Special)(Farmer) - Akhelbhen Salinsithek|Akhelbhen Salinsithek]]"
ownerRace: Wood Elf
apprentices: 
- Willoughby (Young Adult ) Male who is Dead  
services: 
- Farmer( Good   quality, Below Average  costs) 
- Food( Low   quality, Below Average  costs) 
- Herding( Excellent   quality, High  costs) 
exterior: An long building with faded paint and with planked siding with a front round window that has a carved sign hanging to the side with the merchants name. The roof is Celing. A Yellow Birch shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


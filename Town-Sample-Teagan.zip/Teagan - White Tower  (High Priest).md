---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Priest 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: White Tower 
ownerName: Bradshaw Mobbs 
ownerLink: "[[High Priest(Clergy) - Bradshaw Mobbs|Bradshaw Mobbs]]"
ownerRace: Water Genasi
apprentices: 
- Atterton (Adult ) Male who is Hurt  
- Abram (Young Adult ) Female who is Fit  
services: 
- Clergy( Low   quality, Below Average  costs) 
- Scroll Crafting( Horrible   quality, Below Average  costs) 
- Potion Crafting( Poor   quality, Above Average  costs) 
- Spell Research( Excellent   quality, Low  costs) 
- Healing( Good   quality, High  costs) 
exterior: An old tall building with brick siding with a missing window. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


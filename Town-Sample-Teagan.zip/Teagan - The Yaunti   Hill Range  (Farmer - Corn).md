---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Yaunti   Hill Range 
ownerName: Beldroth Arabitlithar 
ownerLink: "[[Farmer - Corn(Farmer) - Beldroth Arabitlithar|Beldroth Arabitlithar]]"
ownerRace: Elf
apprentices: 
- Bradly (Teen ) Female who is Nauseos  
- Milton (Young Adult ) Female who is Healthy  
services: 
- Farmer( Horrible   quality, Low  costs) 
- Food( Average   quality, Above Average  costs) 
exterior: An new building with new paint and with shingled siding with a missing round window. The roof is Celing. A Maple pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Used Garment Trader 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Used surcoat Garmets 
ownerName: Andrathath Bunilirettln 
ownerLink: "[[Used Garment Trader(Garment Trade) - Andrathath Bunilirettln|Andrathath Bunilirettln]]"
ownerRace: High  Elf
apprentices: 
- Dayton (Young Adult ) Male who is Ill  
services: 
- Garment Trade( Average   quality, Below Average  costs) 
- Trader( Horrible   quality, Above Average  costs) 
exterior: An old long building with stoned siding with a few windows. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


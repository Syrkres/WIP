---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: Shrine of the Sensitive 
ownerName: Darby Petcher 
ownerLink: "[[Cleric(Clergy) - Darby Petcher|Darby Petcher]]"
ownerRace: Half-Orc
apprentices: 
- Carlyle (Teen ) Male who is Impaired  
- Stratford (Mature Adult ) Female who is Nauseos  
services: 
- Clergy( Low   quality, Above Average  costs) 
- Religion( Low   quality, High  costs) 
- House of Worship( Good   quality, High  costs) 
- Curse Removal( Low   quality, Below Average  costs) 
- Spell Research( Excellent   quality, Average  costs) 
- Healing( Average   quality, Low  costs) 
- Potions( Poor   quality, Average  costs) 
exterior: An building with faded paint and with brick siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


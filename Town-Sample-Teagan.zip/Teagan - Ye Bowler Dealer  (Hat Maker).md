---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Bowler Dealer 
ownerName: Tyndall Jennings 
ownerLink: "[[Hat Maker(Garment Trade) - Tyndall Jennings|Tyndall Jennings]]"
ownerRace: Deep Gnome
apprentices: 
- Tattersall (Young Adult ) Male who is Healthy  
- Darlington (Adult ) Female who is Unwell  
services: 
- Garment Trade( Excellent   quality, High  costs) 
- Hat Maker( Low   quality, Above Average  costs) 
exterior: An new building with shingled siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


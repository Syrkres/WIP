---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furniture Maker 
merchantCategory: Artisan
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: You can Sit here 
ownerName: Rutherford Pittman 
ownerLink: "[[Furniture Maker(Artisan) - Rutherford Pittman|Rutherford Pittman]]"
ownerRace: Vedalken
apprentices: 
- Graham (Young Adult ) Male who is Healthy  
- Walpole (Young Adult ) Male who is Healthy  
services: 
- Artisan( Good   quality, Below Average  costs) 
- Furniture( Good   quality, Low  costs) 
- Wood Carver( Poor   quality, Below Average  costs) 
- Carpentry( Low   quality, Average  costs) 
exterior: An new building with new paint and with brick siding with a missing round window. The roof is Dome. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


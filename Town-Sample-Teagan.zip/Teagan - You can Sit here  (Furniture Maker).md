---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furniture Maker 
merchantCategory: Artisan
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: You can Sit here 
ownerName: Nopos Sinulathem 
ownerLink: "[[Furniture Maker(Artisan) - Nopos Sinulathem|Nopos Sinulathem]]"
ownerRace: Elf
apprentices: 
- Coombs (Young Adult ) Female who is Dying  
- Reid (Young Adult ) Male who is Wounded  
services: 
- Artisan( Poor   quality, Average  costs) 
- Furniture( Good   quality, Average  costs) 
- Wood Carver( Excellent   quality, Average  costs) 
- Carpentry( Low   quality, Above Average  costs) 
exterior: An tall building with faded paint and with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


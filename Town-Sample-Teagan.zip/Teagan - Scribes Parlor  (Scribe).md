---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe 
merchantCategory: Professional Specialties
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,ALCHEMIST
title: Scribes Parlor 
ownerName: Cornelia Grubbpipe 
ownerLink: "[[Scribe(Professional Specialties) - Cornelia Grubbpipe|Cornelia Grubbpipe]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Graham (Teen ) Male who is Healthy  
services: 
- Research( Horrible   quality, Above Average  costs) 
- Scribe( Excellent   quality, High  costs) 
exterior: An new building with planked siding with a front short window that has a sign hanging above with the merchants name. The roof is Roof. A Oak shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


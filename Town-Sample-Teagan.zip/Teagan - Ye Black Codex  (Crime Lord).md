---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Black Codex 
ownerName: Eastaughffe Rushing 
ownerLink: "[[Crime Lord(Criminal) - Eastaughffe Rushing|Eastaughffe Rushing]]"
ownerRace: Half-Elf
apprentices: 
- Wakefield (Young Adult ) Female who is Healthy  
services: 
- Blackmarket( Low   quality, High  costs) 
- Merchant( Poor   quality, Above Average  costs) 
- Transfer of Goods( Average   quality, Average  costs) 
exterior: An one story building with stoned siding. The roof is Roof. A Hickory shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


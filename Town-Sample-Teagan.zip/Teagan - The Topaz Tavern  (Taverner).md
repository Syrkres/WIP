---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner 
merchantCategory: Hostelers
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Topaz Tavern 
ownerName: Spaulding Belcher 
ownerLink: "[[Taverner(Hostelers) - Spaulding Belcher|Spaulding Belcher]]"
ownerRace: Moon/Sun Half-Elf
apprentices: 
- No apprentices
services: 
- Eatery( Excellent   quality, High  costs) 
- Room (Sleeping)( Poor   quality, Average  costs) 
- Common Room (Sleeping)( Excellent   quality, Above Average  costs) 
- Room (Meeting)( Excellent   quality, Below Average  costs) 
exterior: An narrow tall building with new paint and with shingled siding. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Water Carrier 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Water Sherpa 
ownerName: Phraan Wakirulthym 
ownerLink: "[[Water Carrier(Laborer) - Phraan Wakirulthym|Phraan Wakirulthym]]"
ownerRace: Wood Elf
apprentices: 
- Walpole (Teen ) Male who is Fine  
services: 
- Laborer( Poor   quality, Below Average  costs) 
- Water Carrier( Average   quality, Average  costs) 
exterior: An building with stoned siding with a missing window. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thug 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Tavern 
ownerName: Wakefield Hunt 
ownerLink: "[[Thug(Criminal) - Wakefield Hunt|Wakefield Hunt]]"
ownerRace: Amonkhet Human
apprentices: 
- Eastoft (Young Adult ) Female who is Fine  
- Westbrook (Teen ) Male who is Well  
services: 
- Criminal( Good   quality, Below Average  costs) 
- Deception( Low   quality, Low  costs) 
- Guarding( Horrible   quality, Average  costs) 
exterior: An narrow two story building with planked siding with a missing window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


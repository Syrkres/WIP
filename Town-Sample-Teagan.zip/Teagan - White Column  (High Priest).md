---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Priest 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: White Column 
ownerName: Gormin Daraln 
ownerLink: "[[High Priest(Clergy) - Gormin Daraln|Gormin Daraln]]"
ownerRace: Hill Dwarf
apprentices: 
- Fawcett (Young Adult ) Female who is Nauseos  
services: 
- Clergy( Good   quality, Above Average  costs) 
- Scroll Crafting( Horrible   quality, Average  costs) 
- Potion Crafting( Horrible   quality, Average  costs) 
- Spell Research( Horrible   quality, Low  costs) 
- Healing( Good   quality, Low  costs) 
exterior: An building with shingled siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Headgear Peddler 
ownerName: Zaor Berenannia 
ownerLink: "[[Hat Maker(Garment Trade) - Zaor Berenannia|Zaor Berenannia]]"
ownerRace: Elf
apprentices: 
- Tindall (Teen ) Female who is Fine  
services: 
- Garment Trade( Low   quality, High  costs) 
- Hat Maker( Excellent   quality, Low  costs) 
exterior: An narrow building with planked siding with a few windows. The roof is Roof. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


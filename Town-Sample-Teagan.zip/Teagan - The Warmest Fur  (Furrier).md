---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furrier 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Warmest Fur 
ownerName: Salvia Chetgarden 
ownerLink: "[[Furrier(Garment Trade) - Salvia Chetgarden|Salvia Chetgarden]]"
ownerRace: Stout Halfling
apprentices: 
- Stanton (Adult ) Male who is All Right  
- Perry (Adult ) Male who is Expired  
services: 
- Garment Trade( Horrible   quality, High  costs) 
- Fur Processing( Poor   quality, Above Average  costs) 
exterior: An narrow building with planked siding with a front tall window that has a sign hanging above with the merchants name. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Missionary Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: Ye Missionary 
ownerName: Marroc Goodtea 
ownerLink: "[[Missionary(Clergy) - Marroc Goodtea|Marroc Goodtea]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Barton (Young Adult ) Female who is Under the weather  
services: 
- Clergy( Poor   quality, Below Average  costs) 
- Religion( Poor   quality, Low  costs) 
- Remedies( Average   quality, Above Average  costs) 
exterior: An old long two story building with brick siding with a front broken window that has a sign hanging above with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,STABLE
title: The Fox Club 
ownerName: Clive Quigley 
ownerLink: "[[Barbarian(Merc) - Clive Quigley|Clive Quigley]]"
ownerRace: Kessig Human
apprentices: 
- No apprentices
services: 
- Mercenary( Poor   quality, Low  costs) 
- Tracking( Poor   quality, Above Average  costs) 
exterior: An one story building with brick siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


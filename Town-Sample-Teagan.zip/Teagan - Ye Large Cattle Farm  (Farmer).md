---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Large Cattle Farm 
ownerName: Mardeiym Krulsalwuneldth 
ownerLink: "[[Farmer - Cattle Herder(Farmer) - Mardeiym Krulsalwuneldth|Mardeiym Krulsalwuneldth]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Farmer( Poor   quality, Below Average  costs) 
- Food( Poor   quality, Below Average  costs) 
exterior: An building with planked siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


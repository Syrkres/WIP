---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Knight 
merchantCategory: Knight
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Court Stable 
ownerName: Moryggan Zepomrarrae 
ownerLink: "[[Knight(Knight) - Moryggan Zepomrarrae|Moryggan Zepomrarrae]]"
ownerRace: Eladrin Elf
apprentices: 
- Kirby (Young Adult ) Female who is Fit  
services: 
- Guard( Horrible   quality, High  costs) 
- Religion( Low   quality, Below Average  costs) 
exterior: An new long two story building with new paint and with brick siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


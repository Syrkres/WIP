---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Knight Knight
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Court Stable 
ownerName: Immianthe Bulruzea 
ownerLink: "[[Knight(Knight) - Immianthe Bulruzea|Immianthe Bulruzea]]"
ownerRace: Elf
apprentices: 
- Richmond (Teen ) Male who is Not oneself  
services: 
- Guard( Poor   quality, Below Average  costs) 
- Religion( Average   quality, Above Average  costs) 
exterior: An long tall building with brick siding. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Beech Farm 
ownerName: Bingo Diggerhill 
ownerLink: "[[Farmer - Corn(Farmer) - Bingo Diggerhill|Bingo Diggerhill]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Wesley (Teen ) Female who is Healthy  
services: 
- Farmer( Average   quality, Above Average  costs) 
- Food( Horrible   quality, Low  costs) 
exterior: An old building with stoned siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Fat Piglet Nursery 
ownerName: Gresham Broadribb 
ownerLink: "[[Farmer - Pig Herder(Farmer) - Gresham Broadribb|Gresham Broadribb]]"
ownerRace: Fire Genasi
apprentices: 
- Yeardley (Young Adult ) Female who is Under the weather  
services: 
- Farmer( Excellent   quality, Average  costs) 
- Food( Poor   quality, Above Average  costs) 
- Herding( Low   quality, Average  costs) 
exterior: An old two story building with new paint and with stoned siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Black Book 
ownerName: Kendal Granger 
ownerLink: "[[Crime Lord(Criminal) - Kendal Granger|Kendal Granger]]"
ownerRace: Half-Elf
apprentices: 
- No apprentices
services: 
- Blackmarket( Horrible   quality, Above Average  costs) 
- Merchant( Poor   quality, Low  costs) 
- Transfer of Goods( Excellent   quality, Average  costs) 
exterior: An old two story building with shingled siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


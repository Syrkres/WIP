---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Old Stone Range 
ownerName: Fredegar Diggergee 
ownerLink: "[[Farmer - Potato(Farmer) - Fredegar Diggergee|Fredegar Diggergee]]"
ownerRace: Lightfoot Halfling
apprentices: 
- No apprentices
services: 
- Farmer( Low   quality, Below Average  costs) 
- Food( Low   quality, Above Average  costs) 
exterior: An two story building with shingled siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


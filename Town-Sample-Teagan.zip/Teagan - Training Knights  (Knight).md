---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Squire Knight
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Training Knights 
ownerName: Hayley Lawrence 
ownerLink: "[[Squire(Knight) - Hayley Lawrence|Hayley Lawrence]]"
ownerRace: Human
apprentices: 
- No apprentices
services: 
- Knight( Excellent   quality, Average  costs) 
- Guarding( Horrible   quality, Average  costs) 
exterior: An building with new paint and with brick siding with a few round broken windows. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


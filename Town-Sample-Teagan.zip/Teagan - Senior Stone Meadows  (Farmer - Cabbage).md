---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Senior Stone Meadows 
ownerName: Melisander Tirlomwuntlithar 
ownerLink: "[[Farmer - Cabbage(Farmer) - Melisander Tirlomwuntlithar|Melisander Tirlomwuntlithar]]"
ownerRace: High  Elf
apprentices: 
- Blackwood (Teen ) Female who is Well  
- Milton (Young Adult ) Male who is Healthy  
services: 
- Farmer( Good   quality, Above Average  costs) 
- Food( Excellent   quality, Above Average  costs) 
exterior: An building with new paint and with stoned siding with a missing window. The roof is Dome. A Maple pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker Craftsman
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Silver Cauldron 
ownerName: Filibert Farees 
ownerLink: "[[Kettle Maker(Craftsman) - Filibert Farees|Filibert Farees]]"
ownerRace: Ghostwise Halfling
apprentices: 
- No apprentices
services: 
- Craftsman( Excellent   quality, Low  costs) 
- Merchant( Poor   quality, Average  costs) 
exterior: An new building with stoned siding with a few tall windows. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Old Bovines Farm 
ownerName: Zhoron Zimreneplith 
ownerLink: "[[Farmer - Cow Herder(Farmer) - Zhoron Zimreneplith|Zhoron Zimreneplith]]"
ownerRace: Wood Elf
apprentices: 
- Nibley (Adult ) Male who is Fit  
services: 
- Farmer( Poor   quality, Average  costs) 
- Food( Low   quality, High  costs) 
exterior: An new building with planked siding. The roof is Roof. A Beech pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


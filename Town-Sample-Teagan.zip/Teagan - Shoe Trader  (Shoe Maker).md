---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Shoe Maker 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Shoe Trader 
ownerName: Rhaac'var Aritianarnith 
ownerLink: "[[Shoe Maker(Garment Trade) - Rhaac'var Aritianarnith|Rhaac'var Aritianarnith]]"
ownerRace: Drow
apprentices: 
- Graeme (Child ) Male who is Out of sorts  
- Bristol (Teen ) Male who is Fine  
services: 
- Garment Trade( Low   quality, High  costs) 
- Shoe Maker( Horrible   quality, High  costs) 
exterior: An old long one story building with faded paint and with brick siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


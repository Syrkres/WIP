---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Teachers Union 
ownerName: Merialeth Vulrarrretyn 
ownerLink: "[[Tutor(Sage) - Merialeth Vulrarrretyn|Merialeth Vulrarrretyn]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Sage( Average   quality, High  costs) 
- Teaching( Excellent   quality, High  costs) 
- Research( Excellent   quality, Below Average  costs) 
exterior: An old narrow tall building with shingled siding with a few tall boarded windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: SellSpell Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,ALCHEMIST
title: Casters Store 
ownerName: Roderic Bannburrow 
ownerLink: "[[SellSpell(Sage) - Roderic Bannburrow|Roderic Bannburrow]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Morton (Teen ) Female who is Ailing  
services: 
- Sage( Excellent   quality, High  costs) 
- Spellcraft( Poor   quality, Above Average  costs) 
- Spell Research( Horrible   quality, Above Average  costs) 
- Spell Casting( Low   quality, High  costs) 
exterior: An old narrow tall building with faded paint and with brick siding with a missing window. The roof is Canopy. A Hickory shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: This Past farm 
ownerName: Delsaran Brulgumrighymn 
ownerLink: "[[Farmer(Farmer) - Delsaran Brulgumrighymn|Delsaran Brulgumrighymn]]"
ownerRace: Wood Elf
apprentices: 
- Fulton (Teen ) Female who is All Right  
- Alby (Young Adult ) Female who is Healthy  
services: 
- Farmer( Average   quality, Low  costs) 
- Food( Poor   quality, High  costs) 
exterior: An two story building with shingled siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


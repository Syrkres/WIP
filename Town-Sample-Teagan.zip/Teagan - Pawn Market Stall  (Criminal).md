---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Pawn Market Stall 
ownerName: Branson Inglis 
ownerLink: "[[Crook(Criminal) - Branson Inglis|Branson Inglis]]"
ownerRace: Human
apprentices: 
- Tindall (Teen ) Female who is Fit as a fiddle  
- Merton (Teen ) Male who is Healthy  
services: 
- Criminal( Average   quality, Average  costs) 
- Deception( Good   quality, High  costs) 
- Theft( Good   quality, Below Average  costs) 
exterior: An building with faded paint and with brick siding with a front round window that has a carved sign hanging to the side with the merchants name. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


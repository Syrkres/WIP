---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pirate 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Rotten Mast 
ownerName: Taerntym Hunithrae 
ownerLink: "[[Pirate(Merc) - Taerntym Hunithrae|Taerntym Hunithrae]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Mercenary( Poor   quality, Above Average  costs) 
- Intimidation( Good   quality, Average  costs) 
- Shipping( Average   quality, High  costs) 
- Guarding( Low   quality, Above Average  costs) 
exterior: An narrow tall building with planked siding. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


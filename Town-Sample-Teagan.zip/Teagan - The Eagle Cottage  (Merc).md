---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,STABLE
title: The Eagle Cottage 
ownerName: Hildifons Magtea 
ownerLink: "[[Barbarian(Merc) - Hildifons Magtea|Hildifons Magtea]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Thorpe (Adult ) Female who is Healthy  
- Hailey (Young Adult ) Female who is All Right  
services: 
- Mercenary( Excellent   quality, Low  costs) 
- Tracking( Good   quality, Above Average  costs) 
exterior: An new tall building with new paint and with stoned siding with a front short broken window that has a painted sign hanging above with the merchants name. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tracker Tracker
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: new Club 
ownerName: Aduce Rusirretyn 
ownerLink: "[[Tracker(Tracker) - Aduce Rusirretyn|Aduce Rusirretyn]]"
ownerRace: Elf
apprentices: 
- Hale (Mature Adult ) Male who is Healthy  
services: 
- Tracker( Good   quality, Above Average  costs) 
- Hunter( Good   quality, High  costs) 
exterior: An new long building with stoned siding. The roof is Canopy. A Oak shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


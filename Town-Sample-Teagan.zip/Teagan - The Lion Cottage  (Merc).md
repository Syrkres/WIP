---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,STABLE
title: The Lion Cottage 
ownerName: Chasianna Dresarraheal 
ownerLink: "[[Barbarian(Merc) - Chasianna Dresarraheal|Chasianna Dresarraheal]]"
ownerRace: High  Elf
apprentices: 
- Barney (Teen ) Female who is Healthy  
- Stratford (Young Adult ) Male who is Fit as a fiddle  
services: 
- Mercenary( Excellent   quality, Average  costs) 
- Tracking( Good   quality, Below Average  costs) 
exterior: An long building with shingled siding with a missing round window. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


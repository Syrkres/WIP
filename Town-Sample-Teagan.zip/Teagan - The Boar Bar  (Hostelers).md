---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner Hostelers
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Boar Bar 
ownerName: Jasmine Digglebrace 
ownerLink: "[[Taverner(Hostelers) - Jasmine Digglebrace|Jasmine Digglebrace]]"
ownerRace: Lightfoot Halfling
apprentices: 
- No apprentices
services: 
- Eatery( Average   quality, High  costs) 
- Room (Sleeping)( Excellent   quality, High  costs) 
- Common Room (Sleeping)( Good   quality, Average  costs) 
- Room (Meeting)( Poor   quality, Average  costs) 
exterior: An old narrow tall building with brick siding with a few tall windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


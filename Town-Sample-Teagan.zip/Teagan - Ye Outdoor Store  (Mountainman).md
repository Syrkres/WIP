---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mountainman 
merchantCategory: Tracker
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Outdoor Store 
ownerName: Breeden Noblet 
ownerLink: "[[Mountainman(Tracker) - Breeden Noblet|Breeden Noblet]]"
ownerRace: Amonkhet Human
apprentices: 
- Rodney (Teen ) Female who is All Right  
- Trollope (Mature Adult ) Male who is Expired  
services: 
- Tracker( Low   quality, Average  costs) 
- Hunting( Poor   quality, Above Average  costs) 
exterior: An new long building with faded paint and with stoned siding with a few round windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


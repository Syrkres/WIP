---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Hickory Fields 
ownerName: Mungrima Torevir 
ownerLink: "[[Farmer - Wheat(Farmer) - Mungrima Torevir|Mungrima Torevir]]"
ownerRace: Hill Dwarf
apprentices: 
- Stanford (Adult ) Male who is Healthy  
- Eastaughffe (Teen ) Male who is Dead  
services: 
- Farmer( Horrible   quality, Average  costs) 
- Food( Average   quality, Above Average  costs) 
exterior: An new building with brick siding with a front tall window that has a painted sign hanging above with the merchants name. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


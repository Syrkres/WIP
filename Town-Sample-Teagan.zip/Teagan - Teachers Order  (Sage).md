---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Teachers Order 
ownerName: Kendall Broster 
ownerLink: "[[Tutor(Sage) - Kendall Broster|Kendall Broster]]"
ownerRace: Half-Orc
apprentices: 
- No apprentices
services: 
- Sage( Excellent   quality, Average  costs) 
- Teaching( Horrible   quality, Above Average  costs) 
- Research( Excellent   quality, Low  costs) 
exterior: An building with new paint and with planked siding with a few windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Heavy Cattle Nursery 
ownerName: Cromwell Snuggs 
ownerLink: "[[Farmer - Cattle Herder(Farmer) - Cromwell Snuggs|Cromwell Snuggs]]"
ownerRace: Half-Elf
apprentices: 
- No apprentices
services: 
- Farmer( Horrible   quality, Above Average  costs) 
- Food( Horrible   quality, High  costs) 
exterior: An new one story building with faded paint and with shingled siding with a few boarded windows. The roof is Roof. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker Craftsman
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Blue Steal Kettle 
ownerName: Hildibrand Rumblefin 
ownerLink: "[[Kettle Maker(Craftsman) - Hildibrand Rumblefin|Hildibrand Rumblefin]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Home (Teen ) Male who is Deceased  
services: 
- Craftsman( Excellent   quality, Low  costs) 
- Merchant( Excellent   quality, Low  costs) 
exterior: An long building with new paint and with shingled siding with a few windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


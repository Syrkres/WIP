---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Used Garment Trader Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Used hat Garmets 
ownerName: Sherwood Mosley 
ownerLink: "[[Used Garment Trader(Garment Trade) - Sherwood Mosley|Sherwood Mosley]]"
ownerRace: Half-Orc
apprentices: 
- Westbrook (Child ) Male who is Healthy  
- Graham (Young Adult ) Female who is Healthy  
services: 
- Garment Trade( Average   quality, Low  costs) 
- Trader( Horrible   quality, Above Average  costs) 
exterior: An one story building with planked siding with a front boarded window that has a carved sign hanging to the side with the merchants name. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


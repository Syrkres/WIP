---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Black Tome 
ownerName: Faahresc Takelseannia 
ownerLink: "[[Crime Lord(Criminal) - Faahresc Takelseannia|Faahresc Takelseannia]]"
ownerRace: Bishatar/Tirahar Elf
apprentices: 
- Reed (Young Adult ) Male who is All Right  
services: 
- Blackmarket( Poor   quality, Below Average  costs) 
- Merchant( Poor   quality, Below Average  costs) 
- Transfer of Goods( Excellent   quality, Below Average  costs) 
exterior: An long tall building with shingled siding with a few shuttered windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thief 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Standing Boar Mug 
ownerName: Edansyr Vunilmyrsithek 
ownerLink: "[[Thief(Criminal) - Edansyr Vunilmyrsithek|Edansyr Vunilmyrsithek]]"
ownerRace: High  Elf
apprentices: 
- Ainsworth (Young Adult ) Female who is Fit  
services: 
- Criminal( Excellent   quality, Above Average  costs) 
- Deception( Poor   quality, High  costs) 
exterior: An tall building with planked siding. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


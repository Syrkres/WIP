---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tailor 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Fit Tailor 
ownerName: Sutton Kruse 
ownerLink: "[[Tailor(Garment Trade) - Sutton Kruse|Sutton Kruse]]"
ownerRace: Human
apprentices: 
- Harrington (Young Adult ) Male who is Healthy as a horse  
services: 
- Garment Trade( Average   quality, Below Average  costs) 
- Tailor( Excellent   quality, Above Average  costs) 
exterior: An old tall building with brick siding with a missing window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


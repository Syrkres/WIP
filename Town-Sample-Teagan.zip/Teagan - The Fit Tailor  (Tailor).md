---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tailor 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Fit Tailor 
ownerName: Alston Tink 
ownerLink: "[[Tailor(Garment Trade) - Alston Tink|Alston Tink]]"
ownerRace: Aetherborn
apprentices: 
- Bentham (Adult ) Male who is Fit  
services: 
- Garment Trade( Good   quality, Below Average  costs) 
- Tailor( Low   quality, Average  costs) 
exterior: An new building with brick siding. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Dreamers star Nursery 
ownerName: Mnuvae Melithsithek 
ownerLink: "[[Farmer(Farmer) - Mnuvae Melithsithek|Mnuvae Melithsithek]]"
ownerRace: Mul Daya Nation Elf
apprentices: 
- Sydney (Young Adult ) Male who is Healthy  
- Blankley (Young Adult ) Male who is Healthy  
services: 
- Farmer( Low   quality, Low  costs) 
- Food( Average   quality, Average  costs) 
exterior: An new narrow building with new paint and with planked siding with a few tall boarded windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Sheep Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Wooly Sheep Meadows 
ownerName: Alyndra Dryearghymn 
ownerLink: "[[Farmer - Sheep Herder(Farmer) - Alyndra Dryearghymn|Alyndra Dryearghymn]]"
ownerRace: High  Elf
apprentices: 
- Wharton (Teen ) Female who is Healthy  
- Ramsay (Young Adult ) Male who is Inured  
services: 
- Farmer( Low   quality, Below Average  costs) 
- Food( Low   quality, High  costs) 
- Herding( Poor   quality, Low  costs) 
exterior: An building with brick siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


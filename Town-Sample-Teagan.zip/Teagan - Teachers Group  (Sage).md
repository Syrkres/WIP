---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Teachers Group 
ownerName: Sharaera Ailonarnith 
ownerLink: "[[Tutor(Sage) - Sharaera Ailonarnith|Sharaera Ailonarnith]]"
ownerRace: Wood Elf
apprentices: 
- Crawford (Young Adult ) Male who is Fit as a fiddle  
services: 
- Sage( Excellent   quality, High  costs) 
- Teaching( Good   quality, Above Average  costs) 
- Research( Horrible   quality, High  costs) 
exterior: An new building with faded paint and with shingled siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


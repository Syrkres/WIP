---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Magical Tutor 
merchantCategory: Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,ALCHEMIST
title: The Inventive Tutor 
ownerName: Gruraka Caebrek 
ownerLink: "[[Magical Tutor(Sage) - Gruraka Caebrek|Gruraka Caebrek]]"
ownerRace: Mountain Dwarf
apprentices: 
- No apprentices
services: 
- Sage( Horrible   quality, Average  costs) 
- Spell Research( Low   quality, Above Average  costs) 
- Spell Learning( Poor   quality, High  costs) 
exterior: An old narrow one story building with brick siding with a missing window. The roof is Celing. A Cherry pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


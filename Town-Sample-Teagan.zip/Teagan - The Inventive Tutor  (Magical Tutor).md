---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Magical Tutor 
merchantCategory: Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,ALCHEMIST
title: The Inventive Tutor 
ownerName: Rennyn Crownieritryn 
ownerLink: "[[Magical Tutor(Sage) - Rennyn Crownieritryn|Rennyn Crownieritryn]]"
ownerRace: Wood Elf
apprentices: 
- Alston (Young Adult ) Female who is Fit  
- Cromwell (Child ) Male who is Under the weather  
services: 
- Sage( Low   quality, Low  costs) 
- Spell Research( Horrible   quality, Average  costs) 
- Spell Learning( Excellent   quality, Above Average  costs) 
exterior: An old building with faded paint and with stoned siding with a front round shuttered window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


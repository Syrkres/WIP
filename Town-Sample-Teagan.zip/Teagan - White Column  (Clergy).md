---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Priest Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: White Column 
ownerName: Holman Podheaver 
ownerLink: "[[High Priest(Clergy) - Holman Podheaver|Holman Podheaver]]"
ownerRace: Stout Halfling
apprentices: 
- No apprentices
services: 
- Clergy( Good   quality, Low  costs) 
- Scroll Crafting( Excellent   quality, Average  costs) 
- Potion Crafting( Good   quality, High  costs) 
- Spell Research( Horrible   quality, Above Average  costs) 
- Healing( Excellent   quality, Above Average  costs) 
exterior: An old building with new paint and with planked siding with a few short broken windows. The roof is Celing. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


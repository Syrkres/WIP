---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Sheep Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Senior Sitting Range 
ownerName: Cholmondeley Enriquez 
ownerLink: "[[Farmer - Sheep Herder(Farmer) - Cholmondeley Enriquez|Cholmondeley Enriquez]]"
ownerRace: Nephalia Human
apprentices: 
- Yardley (Teen ) Male who is Healthy  
- Lindsey (Young Adult ) Male who is Hurt  
services: 
- Farmer( Excellent   quality, Low  costs) 
- Food( Excellent   quality, High  costs) 
- Herding( Poor   quality, Low  costs) 
exterior: An new tall building with shingled siding with a front tall window that has a painted sign hanging above with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


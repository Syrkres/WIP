---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker 
merchantCategory: Craftsman
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Bronze Pan 
ownerName: Sutherland Lujan 
ownerLink: "[[Kettle Maker(Craftsman) - Sutherland Lujan|Sutherland Lujan]]"
ownerRace: Deep Gnome
apprentices: 
- No apprentices
services: 
- Craftsman( Average   quality, Below Average  costs) 
- Merchant( Excellent   quality, Below Average  costs) 
exterior: An long building with shingled siding. The roof is Canopy. A Hickory shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


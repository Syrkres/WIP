---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Golden Wheat Hill Farm 
ownerName: Urddusk Baequiatear 
ownerLink: "[[Farmer - Wheat(Farmer) - Urddusk Baequiatear|Urddusk Baequiatear]]"
ownerRace: Elf
apprentices: 
- Royston (Teen ) Female who is Fit  
services: 
- Farmer( Low   quality, High  costs) 
- Food( Poor   quality, Average  costs) 
exterior: An old narrow building with brick siding with a missing window. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


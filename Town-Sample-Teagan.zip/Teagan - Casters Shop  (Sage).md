---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: SellSpell Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,ALCHEMIST
title: Casters Shop 
ownerName: Syviis Rirwoanea 
ownerLink: "[[SellSpell(Sage) - Syviis Rirwoanea|Syviis Rirwoanea]]"
ownerRace: High  Elf
apprentices: 
- Berkeley (Teen ) Male who is Fit  
- Graeme (Young Adult ) Female who is Inured  
services: 
- Sage( Excellent   quality, Below Average  costs) 
- Spellcraft( Average   quality, Low  costs) 
- Spell Research( Horrible   quality, Average  costs) 
- Spell Casting( Poor   quality, Low  costs) 
exterior: An building with planked siding with a missing window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


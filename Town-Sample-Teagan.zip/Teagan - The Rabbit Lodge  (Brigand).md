---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: The Rabbit Lodge 
ownerName: Imizael Opulumnddare 
ownerLink: "[[Brigand(Merc) - Imizael Opulumnddare|Imizael Opulumnddare]]"
ownerRace: Wood Elf
apprentices: 
- Lindsay (Mature Adult ) Female who is Hurt  
services: 
- Mercenary( Low   quality, Average  costs) 
- Enforcement( Average   quality, Average  costs) 
- Intimidation( Excellent   quality, Low  costs) 
exterior: An long two story building with brick siding with a front tall window that has a painted sign hanging above with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


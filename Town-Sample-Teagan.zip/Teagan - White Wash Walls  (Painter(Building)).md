---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Painter(Building) 
merchantCategory: Construction
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: White Wash Walls 
ownerName: Gwynnestri Aleaannia 
ownerLink: "[[Painter(Building)(Construction) - Gwynnestri Aleaannia|Gwynnestri Aleaannia]]"
ownerRace: Drow
apprentices: 
- No apprentices
services: 
- Construction( Good   quality, Above Average  costs) 
- Laborer( Low   quality, High  costs) 
exterior: An new building with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


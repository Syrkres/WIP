---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Painter(Building) 
merchantCategory: Construction
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: White Wash Walls 
ownerName: Marlowe Hale 
ownerLink: "[[Painter(Building)(Construction) - Marlowe Hale|Marlowe Hale]]"
ownerRace: Half-Elf
apprentices: 
- Kimberley (Child ) Female who is Deceased  
- Alby (Adult ) Female who is Healthy  
services: 
- Construction( Poor   quality, High  costs) 
- Laborer( Excellent   quality, High  costs) 
exterior: An long building with new paint and with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


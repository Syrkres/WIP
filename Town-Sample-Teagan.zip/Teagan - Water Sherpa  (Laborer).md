---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Water Carrier Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Water Sherpa 
ownerName: Alston Salgado 
ownerLink: "[[Water Carrier(Laborer) - Alston Salgado|Alston Salgado]]"
ownerRace: Half-Elf
apprentices: 
- Astley (Young Adult ) Female who is All Right  
services: 
- Laborer( Excellent   quality, High  costs) 
- Water Carrier( Average   quality, Average  costs) 
exterior: An new building with planked siding with a front short window that has a sign hanging above with the merchants name. The roof is House. A Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


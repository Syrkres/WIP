---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe Professional Specialties
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,ALCHEMIST
title: Scribes Market Stall 
ownerName: Snowdon Stubbins 
ownerLink: "[[Scribe(Professional Specialties) - Snowdon Stubbins|Snowdon Stubbins]]"
ownerRace: Half-Orc
apprentices: 
- No apprentices
services: 
- Research( Horrible   quality, Below Average  costs) 
- Scribe( Excellent   quality, Average  costs) 
exterior: An new long building with brick siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


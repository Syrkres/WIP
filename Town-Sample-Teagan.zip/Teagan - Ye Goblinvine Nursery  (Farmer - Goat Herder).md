---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Goblinvine Nursery 
ownerName: Thkon Caebrek 
ownerLink: "[[Farmer - Goat Herder(Farmer) - Thkon Caebrek|Thkon Caebrek]]"
ownerRace: Hill Dwarf
apprentices: 
- No apprentices
services: 
- Farmer( Excellent   quality, Above Average  costs) 
- Food( Good   quality, Average  costs) 
- Herding( Excellent   quality, Below Average  costs) 
exterior: An new long two story building with new paint and with brick siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


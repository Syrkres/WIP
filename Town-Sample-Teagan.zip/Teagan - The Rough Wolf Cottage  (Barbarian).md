---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,STABLE
title: The Rough Wolf Cottage 
ownerName: Itham Torerlylth 
ownerLink: "[[Barbarian(Merc) - Itham Torerlylth|Itham Torerlylth]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Mercenary( Low   quality, High  costs) 
- Tracking( Average   quality, Below Average  costs) 
exterior: An new one story building with faded paint and with planked siding. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


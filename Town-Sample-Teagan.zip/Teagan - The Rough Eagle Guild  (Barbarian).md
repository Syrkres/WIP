---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,STABLE
title: The Rough Eagle Guild 
ownerName: Dimana Steelfist 
ownerLink: "[[Barbarian(Merc) - Dimana Steelfist|Dimana Steelfist]]"
ownerRace: Hill Dwarf
apprentices: 
- No apprentices
services: 
- Mercenary( Average   quality, Low  costs) 
- Tracking( Average   quality, Low  costs) 
exterior: An old tall building with faded paint and with brick siding with a missing tall window. The roof is Roof. A Pine shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Candle Maker Specialty Service
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Lighted Path 
ownerName: Brutus Magward 
ownerLink: "[[Candle Maker(Specialty Service) - Brutus Magward|Brutus Magward]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Ridley (Teen ) Male who is Fit  
- Hayden (Teen ) Male who is Healthy  
services: 
- Specialty Service( Good   quality, Average  costs) 
- Candle Making( Excellent   quality, Average  costs) 
exterior: An narrow building with shingled siding with a missing short window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Troubadours 
merchantCategory: Entertainer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Lyrics are Us 
ownerName: Payton Melrose 
ownerLink: "[[Troubadours(Entertainer) - Payton Melrose|Payton Melrose]]"
ownerRace: Half-Orc
apprentices: 
- Digby (Adult ) Male who is Healthy  
- Marston (Young Adult ) Female who is Fine  
services: 
- Entertainer( Horrible   quality, Above Average  costs) 
- Troubadours( Horrible   quality, Low  costs) 
exterior: An old long building with shingled siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


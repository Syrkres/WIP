---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Troubadours 
merchantCategory: Entertainer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Lyrics are Us 
ownerName: Carlyle Tozer 
ownerLink: "[[Troubadours(Entertainer) - Carlyle Tozer|Carlyle Tozer]]"
ownerRace: Aasimar)
apprentices: 
- Carlyle (Adult ) Male who is Nauseos  
services: 
- Entertainer( Excellent   quality, Above Average  costs) 
- Troubadours( Good   quality, Average  costs) 
exterior: An new narrow building with brick siding. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader 
merchantCategory: Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Horse Dealer 
ownerName: Gruunni Hammerstone 
ownerLink: "[[Horse Trader(Merchant) - Gruunni Hammerstone|Gruunni Hammerstone]]"
ownerRace: Hill Dwarf
apprentices: 
- Soames (Teen ) Female who is All Right  
- Tattersall (Teen ) Female who is Hurt  
services: 
- Horse Trading( Average   quality, Low  costs) 
- Trader( Excellent   quality, Below Average  costs) 
- Horse Breeding( Excellent   quality, Average  costs) 
exterior: An old building with new paint and with planked siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


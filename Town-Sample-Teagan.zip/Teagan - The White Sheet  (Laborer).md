---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laundress Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The White Sheet 
ownerName: Reed Friend 
ownerLink: "[[Laundress(Laborer) - Reed Friend|Reed Friend]]"
ownerRace: Half-Elf
apprentices: 
- No apprentices
services: 
- Laborer( Horrible   quality, Average  costs) 
- Cleaning( Horrible   quality, Below Average  costs) 
exterior: An old tall building with brick siding. The roof is Dome. A Hickory shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


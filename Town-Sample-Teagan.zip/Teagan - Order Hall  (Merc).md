---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: Order Hall 
ownerName: Elenshaer Lemenkentlithar 
ownerLink: "[[Merc(Merc) - Elenshaer Lemenkentlithar|Elenshaer Lemenkentlithar]]"
ownerRace: Wood Elf
apprentices: 
- Brent (Young Adult ) Male who is Healthy  
services: 
- Mercenary( Low   quality, Low  costs) 
- Intimidation( Good   quality, High  costs) 
- Guarding( Average   quality, Below Average  costs) 
exterior: An two story building with new paint and with planked siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


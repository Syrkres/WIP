---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader 
merchantCategory: Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Grease Maker 
ownerName: Jo Smialrogers 
ownerLink: "[[Oil Trader(Merchant) - Jo Smialrogers|Jo Smialrogers]]"
ownerRace: Stout Halfling
apprentices: 
- Atherton (Adult ) Female who is Healthy  
- Spalding (Adult ) Female who is Not oneself  
services: 
- Merchant( Good   quality, Above Average  costs) 
- Oil Trader( Horrible   quality, Below Average  costs) 
exterior: An building with shingled siding with a front short boarded window that has a carved sign hanging to the side with the merchants name. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Mage 
merchantCategory: Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,ALCHEMIST
title: Mage Obelisk 
ownerName: Wakefield Dumas 
ownerLink: "[[High Mage(Sage) - Wakefield Dumas|Wakefield Dumas]]"
ownerRace: Earth Genasi
apprentices: 
- Breeden (Adult ) Male who is Expired  
services: 
- Sage( Excellent   quality, High  costs) 
- Scroll Crafting( Average   quality, Below Average  costs) 
- Potion Crafting( Horrible   quality, High  costs) 
- Spell Research( Horrible   quality, High  costs) 
exterior: An narrow building with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mason 
merchantCategory: Construction
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Brick Layer 
ownerName: Camden Mill 
ownerLink: "[[Mason(Construction) - Camden Mill|Camden Mill]]"
ownerRace: Half-Orc
apprentices: 
- Graham (Young Adult ) Female who is Maimed  
- Weston (Young Adult ) Female who is Fine  
services: 
- Construction( Low   quality, High  costs) 
- Laborer( Good   quality, Above Average  costs) 
exterior: An old building with new paint and with brick siding with a few round broken windows. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


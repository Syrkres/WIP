---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Long Beard Goat Nursery 
ownerName: Habaccuc Farbuck 
ownerLink: "[[Farmer - Goat Herder(Farmer) - Habaccuc Farbuck|Habaccuc Farbuck]]"
ownerRace: Stout Halfling
apprentices: 
- No apprentices
services: 
- Farmer( Average   quality, High  costs) 
- Food( Poor   quality, Average  costs) 
- Herding( Horrible   quality, High  costs) 
exterior: An long one story building with faded paint and with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


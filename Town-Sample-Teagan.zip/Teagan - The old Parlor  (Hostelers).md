---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper Hostelers
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The old Parlor 
ownerName: Hastings Grill 
ownerLink: "[[Brothel Keeper(Hostelers) - Hastings Grill|Hastings Grill]]"
ownerRace: Half-Elf
apprentices: 
- No apprentices
services: 
- Room (Pleasure)( Poor   quality, Above Average  costs) 
- Common Room (Sleeping)( Excellent   quality, Below Average  costs) 
- Room (Meeting)( Poor   quality, Average  costs) 
exterior: An new tall building with planked siding with a few round broken windows. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


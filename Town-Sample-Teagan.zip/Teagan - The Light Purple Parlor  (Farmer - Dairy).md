---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Dairy 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Light Purple Parlor 
ownerName: Eldratha Vunilmyratear 
ownerLink: "[[Farmer - Dairy(Farmer) - Eldratha Vunilmyratear|Eldratha Vunilmyratear]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Farmer( Average   quality, Above Average  costs) 
- Milk( Poor   quality, Above Average  costs) 
- Food( Average   quality, Average  costs) 
exterior: An two story building with faded paint and with planked siding with a missing tall window. The roof is Canopy. A Elm shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


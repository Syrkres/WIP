---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furniture Maker 
merchantCategory: Artisan
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Something for the house 
ownerName: Asheton Riddle 
ownerLink: "[[Furniture Maker(Artisan) - Asheton Riddle|Asheton Riddle]]"
ownerRace: Human
apprentices: 
- Harley (Teen ) Female who is Healthy  
- Hallewell (Adult ) Male who is Inured  
services: 
- Artisan( Horrible   quality, Above Average  costs) 
- Furniture( Good   quality, High  costs) 
- Wood Carver( Average   quality, Low  costs) 
- Carpentry( Good   quality, Above Average  costs) 
exterior: An long building with new paint and with planked siding with a few windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Long Beard Goat Meadows 
ownerName: Scudamor Boffhand 
ownerLink: "[[Farmer - Goat Herder(Farmer) - Scudamor Boffhand|Scudamor Boffhand]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Sheldon (Teen ) Female who is Hurt  
services: 
- Farmer( Average   quality, Above Average  costs) 
- Food( Poor   quality, High  costs) 
- Herding( Low   quality, Above Average  costs) 
exterior: An old one story building with shingled siding with a missing round window. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


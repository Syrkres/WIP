---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Federation Structure 
ownerName: Miranda Tunnellyger 
ownerLink: "[[Teamster(Laborer) - Miranda Tunnellyger|Miranda Tunnellyger]]"
ownerRace: Stout Halfling
apprentices: 
- Huxley (Young Adult ) Female who is Fine  
services: 
- Laborer( Average   quality, Low  costs) 
- Teamster( Horrible   quality, Below Average  costs) 
exterior: An building with shingled siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


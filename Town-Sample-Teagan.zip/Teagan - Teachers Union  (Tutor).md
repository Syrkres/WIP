---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor 
merchantCategory: Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Teachers Union 
ownerName: Kuskyn Vulraraear 
ownerLink: "[[Tutor(Sage) - Kuskyn Vulraraear|Kuskyn Vulraraear]]"
ownerRace: Elf
apprentices: 
- Sutherland (Young Adult ) Female who is Healthy  
- Garrick (Young Adult ) Male who is Under the weather  
services: 
- Sage( Poor   quality, Average  costs) 
- Teaching( Excellent   quality, Low  costs) 
- Research( Excellent   quality, Above Average  costs) 
exterior: An new two story building with new paint and with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


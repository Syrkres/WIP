---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Tea, meditation Fields 
ownerName: Halama Ideasvalsa 
ownerLink: "[[Farmer - Cow Herder(Farmer) - Halama Ideasvalsa|Halama Ideasvalsa]]"
ownerRace: Wood Elf
apprentices: 
- Hailey (Mature Adult ) Male who is Fine  
- Elton (Adult ) Male who is At death's door  
services: 
- Farmer( Good   quality, High  costs) 
- Food( Average   quality, Below Average  costs) 
exterior: An old long one story building with planked siding. The roof is Canopy. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


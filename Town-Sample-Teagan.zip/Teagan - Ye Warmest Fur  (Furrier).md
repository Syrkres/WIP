---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furrier 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Warmest Fur 
ownerName: Thiilthan Hlaevalsa 
ownerLink: "[[Furrier(Garment Trade) - Thiilthan Hlaevalsa|Thiilthan Hlaevalsa]]"
ownerRace: Bishatar/Tirahar Elf
apprentices: 
- No apprentices
services: 
- Garment Trade( Excellent   quality, Average  costs) 
- Fur Processing( Excellent   quality, High  costs) 
exterior: An new building with stoned siding with a missing window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


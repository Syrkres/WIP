---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Council Member 
merchantCategory: Elected Official
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Town Hall 
ownerName: Breeden Spaulding 
ownerLink: "[[Council Member(Elected Official) - Breeden Spaulding|Breeden Spaulding]]"
ownerRace: Scourge Aasimar
apprentices: 
- No apprentices
services: 
- Elected Official( Poor   quality, Above Average  costs) 
- Diplomacy( Poor   quality, Above Average  costs) 
- Advise( Horrible   quality, Average  costs) 
exterior: An building with faded paint and with planked siding with a front short shuttered window that has a painted sign hanging above with the merchants name. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


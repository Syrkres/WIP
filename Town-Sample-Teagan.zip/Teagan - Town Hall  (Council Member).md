---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Council Member 
merchantCategory: Elected Official
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Town Hall 
ownerName: Storgoli Frostbeard 
ownerLink: "[[Council Member(Elected Official) - Storgoli Frostbeard|Storgoli Frostbeard]]"
ownerRace: Hill Dwarf
apprentices: 
- Wellington (Adult ) Male who is Healthy  
services: 
- Elected Official( Poor   quality, Average  costs) 
- Diplomacy( Good   quality, High  costs) 
- Advise( Good   quality, Low  costs) 
exterior: An old building with shingled siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker Craftsman
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Silver Pan 
ownerName: Rodney Wenden 
ownerLink: "[[Kettle Maker(Craftsman) - Rodney Wenden|Rodney Wenden]]"
ownerRace: Human
apprentices: 
- Elton (Young Adult ) Male who is Healthy  
services: 
- Craftsman( Average   quality, Above Average  costs) 
- Merchant( Excellent   quality, High  costs) 
exterior: An tall building with faded paint and with stoned siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


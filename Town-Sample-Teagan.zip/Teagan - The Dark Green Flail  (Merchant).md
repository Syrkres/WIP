---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Dark Green Flail 
ownerName: Lazziar Rilynnraheal 
ownerLink: "[[Weapon Dealer(Merchant) - Lazziar Rilynnraheal|Lazziar Rilynnraheal]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Merchant( Good   quality, Above Average  costs) 
- Weapon Dealer( Poor   quality, Average  costs) 
exterior: An old two story building with planked siding with a front broken window that has a carved sign hanging to the side with the merchants name. The roof is Celing. A Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


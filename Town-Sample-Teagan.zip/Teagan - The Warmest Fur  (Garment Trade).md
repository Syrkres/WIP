---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furrier Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Warmest Fur 
ownerName: Ynshael CyGreendlues 
ownerLink: "[[Furrier(Garment Trade) - Ynshael CyGreendlues|Ynshael CyGreendlues]]"
ownerRace: Wood Elf
apprentices: 
- Rowley (Teen ) Male who is Maimed  
- Chester (Adult ) Female who is Dying  
services: 
- Garment Trade( Good   quality, Below Average  costs) 
- Fur Processing( Good   quality, Below Average  costs) 
exterior: An narrow building with stoned siding. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Bowler Maker 
ownerName: Duenna Pipetunnel 
ownerLink: "[[Hat Maker(Garment Trade) - Duenna Pipetunnel|Duenna Pipetunnel]]"
ownerRace: Stout Halfling
apprentices: 
- Clayton (Teen ) Male who is Dying  
services: 
- Garment Trade( Poor   quality, Average  costs) 
- Hat Maker( Excellent   quality, High  costs) 
exterior: An building with new paint and with planked siding with a missing short window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


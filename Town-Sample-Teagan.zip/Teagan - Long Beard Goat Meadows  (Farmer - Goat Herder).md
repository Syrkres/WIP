---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Long Beard Goat Meadows 
ownerName: Alauthshaee Rusisithek 
ownerLink: "[[Farmer - Goat Herder(Farmer) - Alauthshaee Rusisithek|Alauthshaee Rusisithek]]"
ownerRace: Joraga Nation Elf
apprentices: 
- No apprentices
services: 
- Farmer( Excellent   quality, Below Average  costs) 
- Food( Good   quality, Low  costs) 
- Herding( Low   quality, Average  costs) 
exterior: An new building with shingled siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Dome. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Squire 
merchantCategory: Knight
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Training Knights 
ownerName: Brent Jackson 
ownerLink: "[[Squire(Knight) - Brent Jackson|Brent Jackson]]"
ownerRace: Human
apprentices: 
- Denholm (Young Adult ) Male who is Fit  
services: 
- Knight( Average   quality, Low  costs) 
- Guarding( Good   quality, High  costs) 
exterior: An old long building with stoned siding. The roof is Dome. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


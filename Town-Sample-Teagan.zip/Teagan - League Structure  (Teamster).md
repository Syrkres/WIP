---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: League Structure 
ownerName: Alosrin Voldrelelrvis 
ownerLink: "[[Teamster(Laborer) - Alosrin Voldrelelrvis|Alosrin Voldrelelrvis]]"
ownerRace: Elf
apprentices: 
- Willoughby (Teen ) Female who is Indisposed  
- Lindsay (Teen ) Female who is Fit  
services: 
- Laborer( Excellent   quality, Average  costs) 
- Teamster( Good   quality, Above Average  costs) 
exterior: An tall building with stoned siding with a front tall window that has a sign hanging above with the merchants name. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Solid Boar Farm 
ownerName: Taleisin Orleghymn 
ownerLink: "[[Farmer - Pig Herder(Farmer) - Taleisin Orleghymn|Taleisin Orleghymn]]"
ownerRace: High  Elf
apprentices: 
- Ryley (Adult ) Female who is Fit  
services: 
- Farmer( Good   quality, Below Average  costs) 
- Food( Excellent   quality, Below Average  costs) 
- Herding( Average   quality, Low  costs) 
exterior: An building with faded paint and with planked siding with a few tall broken windows. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Barn Stables 
ownerName: Lathlaeril Heasitlithar 
ownerLink: "[[Horse Trader(Merchant) - Lathlaeril Heasitlithar|Lathlaeril Heasitlithar]]"
ownerRace: High  Elf
apprentices: 
- Trollope (Adult ) Female who is Healthy  
- Marston (Teen ) Female who is Healthy  
services: 
- Horse Trading( Poor   quality, Below Average  costs) 
- Trader( Horrible   quality, High  costs) 
- Horse Breeding( Horrible   quality, Above Average  costs) 
exterior: An narrow building with new paint and with stoned siding. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Tall Corn Fields 
ownerName: Ildilyntra Tinvihamettln 
ownerLink: "[[Farmer - Corn(Farmer) - Ildilyntra Tinvihamettln|Ildilyntra Tinvihamettln]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Farmer( Average   quality, Below Average  costs) 
- Food( Horrible   quality, Low  costs) 
exterior: An new two story building with shingled siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weaver Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Weavers 
ownerName: Frodo Bulgebrook 
ownerLink: "[[Weaver(Garment Trade) - Frodo Bulgebrook|Frodo Bulgebrook]]"
ownerRace: Lightfoot Halfling
apprentices: 
- No apprentices
services: 
- Garment Trade( Average   quality, High  costs) 
- Weaver( Low   quality, Below Average  costs) 
exterior: An old long two story building with brick siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


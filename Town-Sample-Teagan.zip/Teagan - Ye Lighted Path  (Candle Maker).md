---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Candle Maker 
merchantCategory: Specialty Service
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Lighted Path 
ownerName: Orgulas Dugstunnel 
ownerLink: "[[Candle Maker(Specialty Service) - Orgulas Dugstunnel|Orgulas Dugstunnel]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Landon (Adult ) Male who is Sick  
services: 
- Specialty Service( Average   quality, High  costs) 
- Candle Making( Horrible   quality, Below Average  costs) 
exterior: An old building with new paint and with stoned siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


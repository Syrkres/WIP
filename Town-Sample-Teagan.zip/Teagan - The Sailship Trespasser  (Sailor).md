---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sailor 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Sailship Trespasser 
ownerName: Saelihn Crultantylar 
ownerLink: "[[Sailor(Merc) - Saelihn Crultantylar|Saelihn Crultantylar]]"
ownerRace: High  Elf
apprentices: 
- Carlton (Adult ) Female who is At death's door  
- Cholmondeley (Child ) Female who is Healthy  
services: 
- Mercenary( Good   quality, Below Average  costs) 
- Sailor( Average   quality, Average  costs) 
- Thug( Poor   quality, Low  costs) 
exterior: An two story building with shingled siding with a front window that has a sign hanging above with the merchants name. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


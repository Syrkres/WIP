---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: SellSpell Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,ALCHEMIST
title: Casters Market Stall 
ownerName: Pandora Rumblebrace 
ownerLink: "[[SellSpell(Sage) - Pandora Rumblebrace|Pandora Rumblebrace]]"
ownerRace: Ghostwise Halfling
apprentices: 
- York (Teen ) Male who is Scraped up  
services: 
- Sage( Low   quality, Below Average  costs) 
- Spellcraft( Poor   quality, Average  costs) 
- Spell Research( Horrible   quality, High  costs) 
- Spell Casting( Good   quality, Average  costs) 
exterior: An narrow building with new paint and with stoned siding with a few round broken windows. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Magical Tutor Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,ALCHEMIST
title: Ye Inventive Tutor 
ownerName: Inigo Duggee 
ownerLink: "[[Magical Tutor(Sage) - Inigo Duggee|Inigo Duggee]]"
ownerRace: Stout Halfling
apprentices: 
- No apprentices
services: 
- Sage( Poor   quality, Below Average  costs) 
- Spell Research( Average   quality, Average  costs) 
- Spell Learning( Horrible   quality, Low  costs) 
exterior: An one story building with faded paint and with stoned siding. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


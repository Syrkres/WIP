---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pirate Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Last Island 
ownerName: Belba Fareheaver 
ownerLink: "[[Pirate(Merc) - Belba Fareheaver|Belba Fareheaver]]"
ownerRace: Stout Halfling
apprentices: 
- No apprentices
services: 
- Mercenary( Horrible   quality, High  costs) 
- Intimidation( Good   quality, Below Average  costs) 
- Shipping( Poor   quality, High  costs) 
- Guarding( Horrible   quality, Below Average  costs) 
exterior: An new narrow tall building with faded paint and with shingled siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


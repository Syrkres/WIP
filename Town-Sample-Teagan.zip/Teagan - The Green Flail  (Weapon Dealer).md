---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
merchantCategory: Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Green Flail 
ownerName: Fortinbras Rumins 
ownerLink: "[[Weapon Dealer(Merchant) - Fortinbras Rumins|Fortinbras Rumins]]"
ownerRace: Stout Halfling
apprentices: 
- No apprentices
services: 
- Merchant( Good   quality, High  costs) 
- Weapon Dealer( Low   quality, Average  costs) 
exterior: An building with stoned siding with a missing tall window. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Mage Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,ALCHEMIST
title: Mage Tower 
ownerName: Belstram Tirlomwunvirrea 
ownerLink: "[[High Mage(Sage) - Belstram Tirlomwunvirrea|Belstram Tirlomwunvirrea]]"
ownerRace: High  Elf
apprentices: 
- Hastings (Young Adult ) Male who is Healthy  
services: 
- Sage( Horrible   quality, Above Average  costs) 
- Scroll Crafting( Low   quality, Low  costs) 
- Potion Crafting( Good   quality, Above Average  costs) 
- Spell Research( Low   quality, Below Average  costs) 
exterior: An new building with faded paint and with shingled siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


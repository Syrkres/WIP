---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Fedora Hawker 
ownerName: Saradas Claygarden 
ownerLink: "[[Hat Maker(Garment Trade) - Saradas Claygarden|Saradas Claygarden]]"
ownerRace: Stout Halfling
apprentices: 
- Wentworth (Teen ) Female who is Healthy  
- Brady (Adult ) Female who is Well  
services: 
- Garment Trade( Average   quality, High  costs) 
- Hat Maker( Good   quality, High  costs) 
exterior: An new building with shingled siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


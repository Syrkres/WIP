---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Dairy 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Emporium 
ownerName: Perry West 
ownerLink: "[[Farmer - Dairy(Farmer) - Perry West|Perry West]]"
ownerRace: Human
apprentices: 
- Compton (Mature Adult ) Female who is Healthy  
services: 
- Farmer( Poor   quality, Below Average  costs) 
- Milk( Good   quality, High  costs) 
- Food( Excellent   quality, Above Average  costs) 
exterior: An new two story building with new paint and with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


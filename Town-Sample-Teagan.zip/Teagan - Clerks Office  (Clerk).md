---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clerk 
merchantCategory: Elected Official
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,CLERK
title: Clerks Office 
ownerName: Droth Zimrennddare 
ownerLink: "[[Clerk(Elected Official) - Droth Zimrennddare|Droth Zimrennddare]]"
ownerRace: Tajuru Nation Elf
apprentices: 
- Stanton (Teen ) Male who is Scraped up  
services: 
- Elected Official( Low   quality, Low  costs) 
- Diplomacy( Excellent   quality, Low  costs) 
- Note Taking( Horrible   quality, Low  costs) 
exterior: An new narrow tall building with faded paint and with brick siding with a missing tall window. The roof is House. A Yellow Birch pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


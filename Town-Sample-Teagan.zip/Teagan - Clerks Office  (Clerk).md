---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clerk 
merchantCategory: Elected Official
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,CLERK
title: Clerks Office 
ownerName: Royal Thacker 
ownerLink: "[[Clerk(Elected Official) - Royal Thacker|Royal Thacker]]"
ownerRace: Half-Orc
apprentices: 
- No apprentices
services: 
- Elected Official( Excellent   quality, Low  costs) 
- Diplomacy( Good   quality, Low  costs) 
- Note Taking( Excellent   quality, High  costs) 
exterior: An old building with stoned siding with a front shuttered window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A Ceder shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


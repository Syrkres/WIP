---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Juggler Entertainer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Laughing Pin 
ownerName: Walpole Carranza 
ownerLink: "[[Juggler(Entertainer) - Walpole Carranza|Walpole Carranza]]"
ownerRace: Half-Orc
apprentices: 
- Sherwood (Young Adult ) Male who is Wounded  
- Oakley (Child ) Male who is Fit as a fiddle  
services: 
- Entertainer( Low   quality, Average  costs) 
- Performance( Average   quality, High  costs) 
exterior: An old building with new paint and with brick siding. The roof is Celing. A Hickory shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


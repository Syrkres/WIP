---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Potato Farm 
ownerName: Hildibrand Dugsman 
ownerLink: "[[Farmer - Potato(Farmer) - Hildibrand Dugsman|Hildibrand Dugsman]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Clayden (Teen ) Female who is Healthy  
- Darby (Teen ) Female who is Fine  
services: 
- Farmer( Excellent   quality, High  costs) 
- Food( Average   quality, Below Average  costs) 
exterior: An new tall building with new paint and with brick siding. The roof is Roof. A Ceder shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


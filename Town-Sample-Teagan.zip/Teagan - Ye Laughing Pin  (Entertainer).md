---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Juggler Entertainer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Laughing Pin 
ownerName: Wade Jordan 
ownerLink: "[[Juggler(Entertainer) - Wade Jordan|Wade Jordan]]"
ownerRace: Half-Orc
apprentices: 
- Wallace (Teen ) Male who is Fit  
- Hallewell (Teen ) Male who is All Right  
services: 
- Entertainer( Low   quality, High  costs) 
- Performance( Low   quality, High  costs) 
exterior: An one story building with stoned siding. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


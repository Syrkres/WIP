---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thief 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Black Market 
ownerName: Andwise Weedsmial 
ownerLink: "[[Thief(Criminal) - Andwise Weedsmial|Andwise Weedsmial]]"
ownerRace: Stout Halfling
apprentices: 
- No apprentices
services: 
- Criminal( Poor   quality, Average  costs) 
- Deception( Good   quality, Average  costs) 
exterior: An building with planked siding with a few boarded windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


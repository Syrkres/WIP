---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,STABLE
title: The Snake Lodge 
ownerName: Clifton Frogley 
ownerLink: "[[Barbarian(Merc) - Clifton Frogley|Clifton Frogley]]"
ownerRace: Human
apprentices: 
- Churchill (Young Adult ) Female who is Maimed  
services: 
- Mercenary( Low   quality, Above Average  costs) 
- Tracking( Horrible   quality, Low  costs) 
exterior: An building with planked siding with a few windows. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


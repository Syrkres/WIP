---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Candle Maker Specialty Service
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Taper 
ownerName: Hobson Weedger 
ownerLink: "[[Candle Maker(Specialty Service) - Hobson Weedger|Hobson Weedger]]"
ownerRace: Ghostwise Halfling
apprentices: 
- No apprentices
services: 
- Specialty Service( Excellent   quality, High  costs) 
- Candle Making( Low   quality, Average  costs) 
exterior: An long one story building with faded paint and with brick siding with a few short windows. The roof is Roof. A Maple pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


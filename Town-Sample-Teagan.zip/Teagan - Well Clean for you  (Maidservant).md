---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Maidservant 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Well Clean for you 
ownerName: Phraan Kielnimneldth 
ownerLink: "[[Maidservant(Laborer) - Phraan Kielnimneldth|Phraan Kielnimneldth]]"
ownerRace: Eladrin Elf
apprentices: 
- Cholmondeley (Young Adult ) Female who is Well  
- Vance (Adult ) Male who is All Right  
services: 
- Laborer( Poor   quality, High  costs) 
- Maid( Excellent   quality, High  costs) 
- Cleaning( Low   quality, Below Average  costs) 
exterior: An building with faded paint and with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Black Manual 
ownerName: Bentham Curtis 
ownerLink: "[[Crime Lord(Criminal) - Bentham Curtis|Bentham Curtis]]"
ownerRace: Half-Orc
apprentices: 
- Livingstone (Young Adult ) Female who is Healthy  
- Ryley (Teen ) Male who is Indisposed  
services: 
- Blackmarket( Good   quality, Below Average  costs) 
- Merchant( Excellent   quality, Below Average  costs) 
- Transfer of Goods( Good   quality, High  costs) 
exterior: An old two story building with stoned siding with a missing short window. The roof is House. A Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


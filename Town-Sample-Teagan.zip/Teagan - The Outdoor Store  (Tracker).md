---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mountainman Tracker
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Outdoor Store 
ownerName: Hallewell Hawkins 
ownerLink: "[[Mountainman(Tracker) - Hallewell Hawkins|Hallewell Hawkins]]"
ownerRace: Half-Elf
apprentices: 
- No apprentices
services: 
- Tracker( Horrible   quality, High  costs) 
- Hunting( Horrible   quality, Below Average  costs) 
exterior: An old one story building with shingled siding with a missing window. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: Company Hall 
ownerName: Ajhalanda CyGreenrae 
ownerLink: "[[Merc(Merc) - Ajhalanda CyGreenrae|Ajhalanda CyGreenrae]]"
ownerRace: High  Elf
apprentices: 
- Eastaughffe (Adult ) Female who is Fit  
services: 
- Mercenary( Excellent   quality, Below Average  costs) 
- Intimidation( Good   quality, Above Average  costs) 
- Guarding( Average   quality, Average  costs) 
exterior: An narrow building with shingled siding. The roof is House. A Elm shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


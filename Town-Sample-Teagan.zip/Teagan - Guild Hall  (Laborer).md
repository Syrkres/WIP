---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Guild Hall 
ownerName: Tobold Gaukburrow 
ownerLink: "[[Laborer(Laborer) - Tobold Gaukburrow|Tobold Gaukburrow]]"
ownerRace: Ghostwise Halfling
apprentices: 
- No apprentices
services: 
- Laborer( Good   quality, Below Average  costs) 
exterior: An one story building with faded paint and with stoned siding. The roof is Roof. A Yellow Birch pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Guild Hall 
ownerName: Clare Cullimore 
ownerLink: "[[Laborer(Laborer) - Clare Cullimore|Clare Cullimore]]"
ownerRace: Abyssal Tiefling
apprentices: 
- Deighton (Teen ) Female who is Fit  
services: 
- Laborer( Good   quality, Below Average  costs) 
exterior: An building with stoned siding with a missing window. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


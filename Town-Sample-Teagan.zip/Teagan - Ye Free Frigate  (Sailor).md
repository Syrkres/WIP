---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sailor 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Free Frigate 
ownerName: Alea Bulrusithek 
ownerLink: "[[Sailor(Merc) - Alea Bulrusithek|Alea Bulrusithek]]"
ownerRace: Bishatar/Tirahar Elf
apprentices: 
- Shirley (Teen ) Female who is Fine  
services: 
- Mercenary( Average   quality, Below Average  costs) 
- Sailor( Excellent   quality, High  costs) 
- Thug( Poor   quality, Above Average  costs) 
exterior: An old long tall building with faded paint and with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


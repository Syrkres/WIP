---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sailor Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Free Frigate 
ownerName: Adamar Brulgumriannia 
ownerLink: "[[Sailor(Merc) - Adamar Brulgumriannia|Adamar Brulgumriannia]]"
ownerRace: Wood Elf
apprentices: 
- Coombs (Teen ) Male who is Out of sorts  
- Winchester (Adult ) Male who is Fine  
services: 
- Mercenary( Horrible   quality, Below Average  costs) 
- Sailor( Excellent   quality, High  costs) 
- Thug( Excellent   quality, Average  costs) 
exterior: An new two story building with planked siding with a front shuttered window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


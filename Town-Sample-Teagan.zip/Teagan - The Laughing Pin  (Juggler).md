---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Juggler 
merchantCategory: Entertainer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Laughing Pin 
ownerName: Wallace Glover 
ownerLink: "[[Juggler(Entertainer) - Wallace Glover|Wallace Glover]]"
ownerRace: Half-Elf
apprentices: 
- Stratford (Teen ) Male who is Dead  
services: 
- Entertainer( Low   quality, Average  costs) 
- Performance( Poor   quality, Average  costs) 
exterior: An building with faded paint and with stoned siding. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


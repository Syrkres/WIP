---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
merchantCategory: Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Light Blue Spear 
ownerName: Holone Ideashuttlarn 
ownerLink: "[[Weapon Dealer(Merchant) - Holone Ideashuttlarn|Holone Ideashuttlarn]]"
ownerRace: Star Elf
apprentices: 
- Hackney (Teen ) Female who is Not oneself  
- Elton (Child ) Male who is Inured  
services: 
- Merchant( Low   quality, Low  costs) 
- Weapon Dealer( Horrible   quality, Above Average  costs) 
exterior: An new two story building with shingled siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


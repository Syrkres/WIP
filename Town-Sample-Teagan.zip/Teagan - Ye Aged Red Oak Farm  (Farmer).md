---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Aged Red Oak Farm 
ownerName: Yesheln� Crogreltalatear 
ownerLink: "[[Farmer(Farmer) - Yesheln� Crogreltalatear|Yesheln� Crogreltalatear]]"
ownerRace: Wood Elf
apprentices: 
- Vance (Adult ) Male who is Healthy  
services: 
- Farmer( Excellent   quality, Average  costs) 
- Food( Average   quality, High  costs) 
exterior: An building with faded paint and with shingled siding. The roof is House. A Red Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


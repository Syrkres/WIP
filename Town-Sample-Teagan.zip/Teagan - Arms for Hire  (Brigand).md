---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: Arms for Hire 
ownerName: Peyton Reilly 
ownerLink: "[[Brigand(Merc) - Peyton Reilly|Peyton Reilly]]"
ownerRace: Half-Elf
apprentices: 
- Acton (Young Adult ) Male who is Nauseos  
- Colby (Teen ) Female who is Not oneself  
services: 
- Mercenary( Average   quality, High  costs) 
- Enforcement( Average   quality, Average  costs) 
- Intimidation( Low   quality, Below Average  costs) 
exterior: An building with stoned siding. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The White Mace 
ownerName: Gundolpho Dugshair 
ownerLink: "[[Weapon Dealer(Merchant) - Gundolpho Dugshair|Gundolpho Dugshair]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Langdon (Adult ) Female who is Incapacitaed  
- Lancaster (Teen ) Male who is Fine  
services: 
- Merchant( Average   quality, Average  costs) 
- Weapon Dealer( Excellent   quality, Below Average  costs) 
exterior: An building with new paint and with planked siding with a few tall windows. The roof is Dome. A Beech shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


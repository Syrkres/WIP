---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Conjourer Entertainer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Summoned Stone 
ownerName: Alerathla Migalghymn 
ownerLink: "[[Conjourer(Entertainer) - Alerathla Migalghymn|Alerathla Migalghymn]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Entertainer( Poor   quality, Average  costs) 
- Performance( Good   quality, Above Average  costs) 
exterior: An new two story building with new paint and with shingled siding with a few round windows. The roof is Roof. A Cherry shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


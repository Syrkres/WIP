---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader 
merchantCategory: Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Barn Stables 
ownerName: Alavara Cienrinannia 
ownerLink: "[[Horse Trader(Merchant) - Alavara Cienrinannia|Alavara Cienrinannia]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Horse Trading( Average   quality, Low  costs) 
- Trader( Poor   quality, Average  costs) 
- Horse Breeding( Low   quality, Low  costs) 
exterior: An new long tall building with faded paint and with stoned siding with a few short shuttered windows. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


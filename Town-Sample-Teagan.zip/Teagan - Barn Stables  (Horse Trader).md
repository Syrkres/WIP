---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader 
merchantCategory: Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Barn Stables 
ownerName: Aneirin Auvrealylth 
ownerLink: "[[Horse Trader(Merchant) - Aneirin Auvrealylth|Aneirin Auvrealylth]]"
ownerRace: Star Elf
apprentices: 
- Stafford (Young Adult ) Male who is Dying  
- Braxton (Adult ) Male who is Healthy  
services: 
- Horse Trading( Low   quality, Above Average  costs) 
- Trader( Average   quality, Average  costs) 
- Horse Breeding( Low   quality, Below Average  costs) 
exterior: An new building with faded paint and with planked siding with a missing window. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Candle Maker 
merchantCategory: Specialty Service
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye old Candle 
ownerName: Jasmine Noakesblower 
ownerLink: "[[Candle Maker(Specialty Service) - Jasmine Noakesblower|Jasmine Noakesblower]]"
ownerRace: Stout Halfling
apprentices: 
- Darlington (Young Adult ) Female who is Healthy  
- Wharton (Young Adult ) Male who is Dead  
services: 
- Specialty Service( Horrible   quality, Average  costs) 
- Candle Making( Horrible   quality, Above Average  costs) 
exterior: An old building with brick siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


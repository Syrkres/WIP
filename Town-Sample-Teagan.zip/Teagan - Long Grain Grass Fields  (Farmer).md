---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Long Grain Grass Fields 
ownerName: Ruardh Vulrarneldth 
ownerLink: "[[Farmer - Wheat(Farmer) - Ruardh Vulrarneldth|Ruardh Vulrarneldth]]"
ownerRace: High  Elf
apprentices: 
- Appleton (Teen ) Female who is All Right  
- Denholm (Child ) Male who is Healthy  
services: 
- Farmer( Low   quality, Above Average  costs) 
- Food( Horrible   quality, High  costs) 
exterior: An new two story building with stoned siding with a missing short window. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


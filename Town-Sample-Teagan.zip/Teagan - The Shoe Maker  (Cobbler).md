---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cobbler 
merchantCategory: Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Shoe Maker 
ownerName: Rhangyl Arkeneaeplith 
ownerLink: "[[Cobbler(Garment Trade) - Rhangyl Arkeneaeplith|Rhangyl Arkeneaeplith]]"
ownerRace: Star Elf
apprentices: 
- Ashley (Adult ) Female who is Expired  
- Hayes (Young Adult ) Male who is Healthy  
services: 
- Garment Trade( Good   quality, Low  costs) 
- Shoe Repair( Excellent   quality, High  costs) 
exterior: An new building with shingled siding with a front shuttered window that has a painted sign hanging above with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


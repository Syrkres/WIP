---
fileType: npc
Art: halfbreedBanner01.png
Name: Kendal
Surname: Granger
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Elf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Squat frail build, with brown eyes and short black hair. Their face is pock-marked and their speech is loud 
Age: Adult 
Condition: Under the weather 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Heights 
    - Politics 
    - Keys 
    - Parades 
Dislikes: 
    - Getting lost 
Acquaintances: 
PrimaryOccupation: Crime Lord
PrimaryOccupationCategory: Criminal
Occupation:
    - Crime Lord 
Importance: 9
SpouseName: Whitby(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Dead 
Parents: 
    - Quinton(Mother) Elderly  Female who is Deceased
    - Darby(Father) Elderly  Male who is Deceased
Children: 
    No Children
AssociatedGroup:
    - Thieves Guild 
AssociatedReligion:
PersonalityTrait:
- Optimistic  
SocialTrait:
- Helpful  
- Suspicious  
- Selfish  
MentalTrait:
- Decisive  
- Uninventive  
- Tenacious  
PersonalGoals: Free the animals. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

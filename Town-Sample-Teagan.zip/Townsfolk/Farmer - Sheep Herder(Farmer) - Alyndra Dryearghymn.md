---
fileType: npc
Art: elvenBanner01.png
Name: Alyndra
Surname: Dryearghymn
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Extra short lean build, with brown eyes and wiry black hair. Their face has small scar on right cheek and their speech is a guttural slur 
Age: Adult 
Condition: Incapacitaed 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Farming 
    - Fitted clothing 
    - Chalk 
    - Forests 
Dislikes: 
    - Bird watching 
    - Chalk 
    - Falconry 
    - Open spaces 
Acquaintances: 
PrimaryOccupation: Farmer - Sheep Herder
PrimaryOccupationCategory: Farmer
Occupation:
    - Farmer - Sheep Herder 
Importance: 3
SpouseName: Triktappic(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Fine 
Parents: 
    - Anhaern(Mother) Ancient  Female who is Out of sorts 
    - Jhuvik(Father) Elderly  Male who is Deceased
Children: 
    - Kileontheal(Child) Child  Girl who is Ailing  
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Smooth  
- Dull  
SocialTrait:
- Bossy  
- Helpful  
- Friendly  
MentalTrait:
- Independent  
PersonalGoals: Protect their business. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

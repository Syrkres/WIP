---
fileType: npc
Art: humanBanner01.png
Name: Hayden
Surname: Gibson
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Nephalia Human
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Short average build, with red eyes and pony-tail grey hair. Their face is doe-eyed and their speech is wheezy 
Age: Adult 
Condition: Deceased 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Treasure hunting 
    - Lamb 
Dislikes: 
    - Drama 
Acquaintances: 
PrimaryOccupation: Goon
PrimaryOccupationCategory: Criminal
Occupation:
    - Goon 
Importance: 1
SpouseName: York(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Wilberforce(Mother) Elderly  Female who is Deceased
    - Westbrook(Father) Elderly  Male who is Fit as a fiddle 
Children: 
    No Children
AssociatedGroup:
    - Thieves Guild 
AssociatedReligion:
PersonalityTrait:
- Listless  
- Funny  
SocialTrait:
- Helpful  
- Selfish  
MentalTrait:
- Independent  
- Stupid  
- Secular  
PersonalGoals: Win a competition. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[humanBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

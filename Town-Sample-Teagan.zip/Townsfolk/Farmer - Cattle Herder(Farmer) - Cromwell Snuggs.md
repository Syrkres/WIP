---
fileType: npc
Art: halfbreedBanner01.png
Name: Cromwell
Surname: Snuggs
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Elf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Short frail build, with white eyes and well groomed black hair. Their face has a bushy eyebrows and their speech is fast 
Age: Adult 
Condition: At death's door 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Lockpicking 
Dislikes: 
    - Metalworking 
    - Manners 
Acquaintances: 
PrimaryOccupation: Farmer - Cattle Herder
PrimaryOccupationCategory: Farmer
Occupation:
    - Farmer - Cattle Herder 
Importance: 3
SpouseName: Alton(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Impaired 
Parents: 
    - Ramsay(Mother) Elderly  Female who is Deceased
    - Pickering(Father) Adult  Male who is Deceased
Children: 
    - Beverly(Child) Young Adult  Girl who is Healthy as a horse  
    - Tatum(Child) Child  Boy who is Fit  
    - Barney(Child) Infant  Boy who is Fine  
AssociatedGroup:
    - Mages Guild 
AssociatedReligion:
PersonalityTrait:
- Gentle  
- Polite  
SocialTrait:
- Unfriendly  
- Trusting  
- Bossy  
MentalTrait:
- Independent  
PersonalGoals: Make sure justice prevails. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

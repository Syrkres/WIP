---
fileType: npc
Art: halflingBanner01.png
Name: Falco
Surname: Gooldfoot
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Lightfoot Halfling
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Normal fat build, with white eyes and streaked brown hair. Their face has small scar on left cheek and their speech is low-pitched 
Age: Adult 
Condition: Sick 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Meditation 
    - Money 
    - Soap carving 
Dislikes: 
    - Gardens 
    - Sword 
    - Children 
Acquaintances: 
PrimaryOccupation: Antiquities
PrimaryOccupationCategory: Merchant
Occupation:
    - Antiquities 
Importance: 4
SpouseName: Rosamunda(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Hurt 
Parents: 
    - Amalda(Mother) Adult  Female who is Hurt 
    - Bandobras(Father) Adult  Male who is Healthy 
Children: 
    - Vigo(Child) Child  Boy who is Well  
    - Berylla(Child) Young Adult  Girl who is Fine  
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Funny  
SocialTrait:
- Tolerant  
- Peaceful  
- Uncooperative  
MentalTrait:
- Reckless  
- Courageous  
PersonalGoals: Remain hidden. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

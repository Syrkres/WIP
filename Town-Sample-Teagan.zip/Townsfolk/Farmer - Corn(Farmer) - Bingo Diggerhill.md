---
fileType: npc
Art: halflingBanner01.png
Name: Bingo
Surname: Diggerhill
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Ghostwise Halfling
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Extra short average build, with brown eyes and pony-tail auburn hair. Their face has acne and their speech is halting 
Age: Adult 
Condition: Sick 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Fishing 
    - Hen 
Dislikes: 
    - Hills 
    - Rivers 
    - Pottery 
    - Buttons 
Acquaintances: 
PrimaryOccupation: Farmer - Corn
PrimaryOccupationCategory: Farmer
Occupation:
    - Farmer - Corn 
Importance: 3
SpouseName: Estella(Wife)
SpouseAge: Young Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Pearl(Mother) Elderly  Female who is Deceased
    - Roderic(Father) Elderly  Male who is Dying 
Children: 
    No Children
AssociatedGroup:
    - Mages Guild 
AssociatedReligion:
PersonalityTrait:
- Smooth  
- Humble  
SocialTrait:
- Talkative  
- Unfair  
- Suspicious  
MentalTrait:
- Secular  
PersonalGoals: Belong somewhere. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

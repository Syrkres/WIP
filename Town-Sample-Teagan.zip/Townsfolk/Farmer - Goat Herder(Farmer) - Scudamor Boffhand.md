---
fileType: npc
Art: halflingBanner01.png
Name: Scudamor
Surname: Boffhand
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Lightfoot Halfling
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Extra tall wide build, with red eyes and braided grey hair. Their face has large scar across full face and their speech is low-pitched 
Age: Young Adult 
Condition: Healthy 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Birthdays 
    - Heights 
    - Fairy tales 
Dislikes: 
    - Knife throwing 
    - BOOKTYPE 
Acquaintances: 
PrimaryOccupation: Farmer - Goat Herder
PrimaryOccupationCategory: Farmer
Occupation:
    - Farmer - Goat Herder 
Importance: 3
SpouseName: Peony(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Robinia(Mother) Elderly  Female who is Not oneself 
    - Tóbias(Father) Ancient  Male who is Healthy 
Children: 
    No Children
AssociatedGroup:
    - Mages Guild 
AssociatedReligion:
PersonalityTrait:
- Humble  
SocialTrait:
- Unreliable  
- Trusting  
- Tolerant  
MentalTrait:
- Skillful  
- Religious  
- Emotional  
PersonalGoals: Find a thrilling life. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

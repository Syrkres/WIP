---
fileType: npc
Art: halflingBanner01.png
Name: Samwise
Surname: Sandbrace
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Stout Halfling
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Average frail build, with red eyes and braided red hair. Their face is squinty and their speech is squeaky 
Age: Adult 
Condition: Expired 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Jumping in puddles 
    - Kites 
Dislikes: 
    - Danger 
    - Social events 
Acquaintances: 
PrimaryOccupation: Conjourer
PrimaryOccupationCategory: Entertainer
Occupation:
    - Conjourer 
Importance: 9
SpouseName: Lobelia(Wife)
SpouseAge: Young Adult 
SpouseGender: Female
SpouseCondition: Impaired 
Parents: 
    - Poppy(Mother) Ancient  Female who is Deceased
    - Jago(Father) Adult  Male who is Deceased
Children: 
    - Ferumbras(Child) Infant  Boy who is Nauseos  
    - Bellisima(Child) Teen  Girl who is Healthy  
AssociatedGroup:
    - Entertainer Union 
AssociatedReligion:
PersonalityTrait:
- Humorless  
- Humorless  
SocialTrait:
- Lenient  
- Unfair  
MentalTrait:
- Uninventive  
PersonalGoals: Find a lost lover. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

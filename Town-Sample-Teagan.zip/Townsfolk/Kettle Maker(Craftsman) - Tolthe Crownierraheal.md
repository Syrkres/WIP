---
fileType: npc
Art: elvenBanner01.png
Name: Tolthe
Surname: Crownierraheal
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Tajuru Nation Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Extra tall lean build, with red eyes and curly red hair. Their face has small scar and their speech is with lisps 
Age: Adult 
Condition: Healthy 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Staying inside 
Dislikes: 
    - Tutoring 
    - Dolls 
Acquaintances: 
PrimaryOccupation: Kettle Maker
PrimaryOccupationCategory: Craftsman
Occupation:
    - Kettle Maker 
Importance: 7
SpouseName: Tira�allara(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Well 
Parents: 
    - Renestrae(Mother) Elderly  Female who is Deceased
    - Ninthalor(Father) Elderly  Male who is Deceased
Children: 
    - Rubrae(Child) Young Adult  Girl who is All Right  
    - Tannivh(Child) Young Adult  Boy who is Fine  
    - Teharissa(Child) Teen  Girl who is Unwell  
AssociatedGroup:
    - Craftsman Guild 
AssociatedReligion:
PersonalityTrait:
- Repulsive  
SocialTrait:
- Honest  
MentalTrait:
- Skeptical  
- Adaptive  
- Reckless  
PersonalGoals: Be strong. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

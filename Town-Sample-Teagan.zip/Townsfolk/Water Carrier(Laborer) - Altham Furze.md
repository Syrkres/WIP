---
fileType: npc
Art: halfbreedBanner01.png
Name: Altham
Surname: Furze
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Changeling
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Tall anorexic build, with brown eyes and messy black hair. Their face has a patch over left eye and their speech is raspy 
Age: Mature Adult 
Condition: Fit 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Money 
    - Closed spaces 
Dislikes: 
    - Certain people 
    - Mace 
    - Reading books 
Acquaintances: 
PrimaryOccupation: Water Carrier
PrimaryOccupationCategory: Laborer
Occupation:
    - Water Carrier 
Importance: 1
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Pinkerton(Mother) Elderly  Female who is All Right 
    - Acton(Father) Elderly  Male who is Sick 
Children: 
    - Nash(Child) Child  Girl who is All Right  
    - Marston(Child) Child  Boy who is All Right  
AssociatedGroup:
    - Union 
AssociatedReligion:
PersonalityTrait:
- Funny  
- Depressed  
SocialTrait:
- Uncooperative  
- Demanding  
- Peaceful  
MentalTrait:
- Indecisive  
- Skillful  
- Comformist  
PersonalGoals: Become powerful. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

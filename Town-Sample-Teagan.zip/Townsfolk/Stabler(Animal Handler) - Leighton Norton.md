---
fileType: npc
Art: humanBanner01.png
Name: Leighton
Surname: Norton
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Human Variant
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Normal lean build, with white eyes and dreadlocks blond hair. Their face is buck-toothed and their speech is nervous 
Age: Adult 
Condition: Healthy 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Hand holding 
    - Falconry 
Dislikes: 
    - Abandoned buildings 
    - The sound of birds in the morning 
    - The stars 
    - Extravagant things 
Acquaintances: 
PrimaryOccupation: Stabler
PrimaryOccupationCategory: Animal Handler
Occupation:
    - Stabler 
Importance: 4
SpouseName: Brownrigg(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Impaired 
Parents: 
    - Holton(Mother) Adult  Female who is Wounded 
    - Lindsay(Father) Elderly  Male who is Deceased
Children: 
    No Children
AssociatedGroup:
    - Mages Guild 
AssociatedReligion:
PersonalityTrait:
- Thick-skinned  
- Smooth  
SocialTrait:
- Dependable  
- Dependable  
- Forthcoming  
MentalTrait:
- Comformist  
PersonalGoals: Create a work of art. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[humanBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

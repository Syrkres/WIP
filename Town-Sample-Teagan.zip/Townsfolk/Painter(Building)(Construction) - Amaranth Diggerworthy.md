---
fileType: npc
Art: halflingBanner01.png
Name: Amaranth
Surname: Diggerworthy
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Lightfoot Halfling
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Average strong build, with green eyes and very long auburn hair. Their face has acne and their speech is squeaky 
Age: Adult 
Condition: Fine 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Quilting 
    - Training pets to do tricks 
Dislikes: 
    - Pottery 
    - Certain clothes & fashion styles 
    - Repairing items 
Acquaintances: 
PrimaryOccupation: Painter(Building)
PrimaryOccupationCategory: Construction
Occupation:
    - Painter(Building) 
Importance: 7
SpouseName: Dudo(Husband)
SpouseAge: Young Adult 
SpouseGender: Male
SpouseCondition: Well 
Parents: 
    - Peony(Mother) Elderly  Female who is Deceased
    - Paladin(Father) Ancient  Male who is Deceased
Children: 
    - Daisy(Child) Child  Girl who is Healthy  
    - Dora(Child) Child  Girl who is Ailing  
    - Bob(Child) Infant  Boy who is Fine  
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Impolite  
- Listless  
SocialTrait:
- Deferential  
- Stingy  
MentalTrait:
- Emotional  
- Religious  
- Skeptical  
PersonalGoals: Explore the unexplored. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

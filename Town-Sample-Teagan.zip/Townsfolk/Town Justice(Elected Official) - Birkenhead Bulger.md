---
fileType: npc
Art: halfbreedBanner01.png
Name: Birkenhead
Surname: Bulger
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Orc
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Average lean build, with white eyes and dreadlocks red hair. Their face has large scar on left cheek and their speech is whispery 
Age: Elderly 
Condition: Unwell 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Pirates 
    - Sword 
    - Bird watching 
Dislikes: 
    - Rain 
    - Puzzles 
    - Darts 
Acquaintances: 
PrimaryOccupation: Town Justice
PrimaryOccupationCategory: Elected Official
Occupation:
    - Town Justice 
Importance: 10
SpouseName: Reed(Wife)
SpouseAge: Elderly 
SpouseGender: Female
SpouseCondition: Fit 
Parents: 
    - Bradshaw(Mother) Elderly  Female who is Fine 
    - Langley(Father) Ancient  Male who is All Right 
Children: 
    No Children
AssociatedGroup:
    - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Depressed  
SocialTrait:
- Secretive  
MentalTrait:
- Reckless  
- Incompetent  
PersonalGoals: Free the animals. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

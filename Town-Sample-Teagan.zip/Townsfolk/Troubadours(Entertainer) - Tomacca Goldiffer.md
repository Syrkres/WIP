---
fileType: npc
Art: halflingBanner01.png
Name: Tomacca
Surname: Goldiffer
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Stout Halfling
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Grand athletic build, with hazel eyes and messy red hair. Their face is chiseled and their speech is accented 
Age: Young Adult 
Condition: Fine 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Decorating 
    - Open windows 
    - Puzzles 
Dislikes: 
    - Clouds 
Acquaintances: 
PrimaryOccupation: Troubadours
PrimaryOccupationCategory: Entertainer
Occupation:
    - Troubadours 
Importance: 2
SpouseName: Diamond(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Fit as a fiddle 
Parents: 
    - Dina(Mother) Ancient  Female who is Well 
    - Habaccuc(Father) Elderly  Male who is Incapacitaed 
Children: 
    - Lalia(Child) Child  Girl who is Dead  
    - Pansy(Child) Infant  Girl who is Healthy  
AssociatedGroup:
    - Entertainer Union 
AssociatedReligion:
PersonalityTrait:
- Humorless  
- Funny  
SocialTrait:
- Selfless  
- Trusting  
MentalTrait:
- Perceptive  
- Reckless  
- Superstitious  
PersonalGoals: Find inspiration. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

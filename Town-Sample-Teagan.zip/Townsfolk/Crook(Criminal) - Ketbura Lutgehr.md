---
fileType: npc
Art: dwarvenBanner01.png
Name: Ketbura
Surname: Lutgehr
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Hill Dwarf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Average thin build, with white eyes and wiry red hair. Their face has large scar and their speech is slured 
Age: Mature Adult 
Condition: Under the weather 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - The moon 
    - Jumping in puddles 
    - Touching 
Dislikes: 
    - Glass blowing 
Acquaintances: 
PrimaryOccupation: Crook
PrimaryOccupationCategory: Criminal
Occupation:
    - Crook 
Importance: 1
SpouseName: Ovund(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Fine 
Parents: 
    - Gruraka(Mother) Adult  Female who is Deceased
    - Naldri(Father) Adult  Male who is Deceased
Children: 
    No Children
AssociatedGroup:
    - Thieves Guild 
AssociatedReligion:
PersonalityTrait:
- Mature  
- Gentle  
SocialTrait:
- Quite  
- Unreliable  
- Tolerant  
MentalTrait:
- Stupid  
PersonalGoals: Make sure justice prevails. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

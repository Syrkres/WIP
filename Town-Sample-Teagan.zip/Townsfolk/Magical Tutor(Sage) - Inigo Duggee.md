---
fileType: npc
Art: halflingBanner01.png
Name: Inigo
Surname: Duggee
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Stout Halfling
Alignment: chaotic
Gender: Female
Sexuality: Bisexual 
Appearance: Normal frail build, with white eyes and greasy auburn hair. Their face is buck-toothed and their speech is slured 
Age: Adult 
Condition: Healthy 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Fitted clothing 
    - Architecture 
    - The stars 
    - Certain people 
Dislikes: 
    - Architecture 
    - Alcohol 
    - Laying on the floor 
Acquaintances: 
PrimaryOccupation: Magical Tutor
PrimaryOccupationCategory: Sage
Occupation:
    - Magical Tutor 
Importance: 9
SpouseName: Daisy(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: All Right 
Parents: 
    - Matilda(Mother) Elderly  Female who is Deceased
    - Moro(Father) Elderly  Male who is Well 
Children: 
    No Children
AssociatedGroup:
    - Mages Circle 
AssociatedReligion:
PersonalityTrait:
- Funny  
- Mature  
SocialTrait:
- Friendly  
MentalTrait:
- Reckless  
PersonalGoals: Fix a mistake. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

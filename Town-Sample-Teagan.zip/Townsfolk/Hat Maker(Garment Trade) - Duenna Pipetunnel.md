---
fileType: npc
Art: halflingBanner01.png
Name: Duenna
Surname: Pipetunnel
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Stout Halfling
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Short thin build, with white eyes and bald auburn hair. Their face has large scar on right cheek and their speech is whiny 
Age: Adult 
Condition: Sick 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Laying on the floor 
    - Bells 
    - Crafts 
    - Sailing 
Dislikes: 
    - Bird watching 
    - Mountains 
    - Going outside 
    - Shopping 
Acquaintances: 
PrimaryOccupation: Hat Maker
PrimaryOccupationCategory: Garment Trade
Occupation:
    - Hat Maker 
Importance: 4
SpouseName: Gerontius(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Healthy 
Parents: 
    - Malva(Mother) Elderly  Female who is Deceased
    - Herugar(Father) Elderly  Male who is Healthy 
Children: 
    - Laura(Child) Young Adult  Girl who is Inured  
    - Tolman(Child) Young Adult  Boy who is Well  
    - Chica(Child) Child  Girl who is Healthy  
AssociatedGroup:
    - Entertainer Union 
AssociatedReligion:
PersonalityTrait:
- Smooth  
SocialTrait:
- Selfless  
- Stingy  
MentalTrait:
- Superstitious  
- Skeptical  
PersonalGoals: Change the past. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

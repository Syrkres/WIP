---
fileType: npc
Art: unknownBanner01.png
Name: Home
Surname: Ramirez
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Deep Gnome
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Tall athletic build, with brown eyes and well groomed red hair. Their face has no eyebrows and their speech is slow 
Age: Adult 
Condition: Healthy 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Pranks 
    - Sudden movements 
    - Treasure hunting 
    - Learning 
Dislikes: 
    - The stars 
    - Rain 
    - Woodworking 
Acquaintances: 
PrimaryOccupation: Town Justice
PrimaryOccupationCategory: Elected Official
Occupation:
    - Town Justice 
Importance: 10
SpouseName: Stanton(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: All Right 
Parents: 
    - Morley(Mother) Adult  Female who is Deceased
    - Garrick(Father) Elderly  Male who is Healthy 
Children: 
    - Peyton(Child) Infant  Boy who is Expired  
AssociatedGroup:
    - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Pessimistic  
SocialTrait:
- Deferential  
- Intolerant  
- Peaceful  
MentalTrait:
- Adaptive  
- Uninventive  
PersonalGoals: Escape a bad situation. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[unknownBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

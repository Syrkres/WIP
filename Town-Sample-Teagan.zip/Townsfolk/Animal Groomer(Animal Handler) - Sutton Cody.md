---
fileType: npc
Art: halfbreedBanner01.png
Name: Sutton
Surname: Cody
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Orc
Alignment: chaotic
Gender: Male
Sexuality: Gay 
Appearance: Grand lean build, with hazel eyes and wavy red hair. Their face has a goatee and their speech is halting 
Age: Adult 
Condition: Maimed 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Singing 
    - Rain 
    - Beekeeping 
    - Pirates 
Dislikes: 
    - Jumping in puddles 
    - Crowds 
    - Baking 
    - Cave exploring 
Acquaintances: 
PrimaryOccupation: Animal Groomer
PrimaryOccupationCategory: Animal Handler
Occupation:
    - Animal Groomer 
Importance: 4
SpouseName: Thackeray(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Crawford(Mother) Elderly  Female who is Fit 
    - Clayden(Father) Elderly  Male who is Healthy 
Children: 
    - Berkeley(Child) Teen  Girl who is Fine  
    - Stansfield(Child) Young Adult  Girl who is Hurt  
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Impolite  
- Polite  
SocialTrait:
- Loyal  
- Unreliable  
- Quite  
MentalTrait:
- Ambitious  
PersonalGoals: Be accepted by society. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

---
fileType: npc
Art: humanBanner01.png
Name: Ryley
Surname: Mudge
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Human
Alignment: chaotic
Gender: Male
Sexuality: Bisexual 
Appearance: Tall anorexic build, with white eyes and thinning grey hair. Their face has large scar on right cheek and their speech is fast 
Age: Young Adult 
Condition: Impaired 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Mythology 
    - Surprises 
    - Learning 
Dislikes: 
    - Grape 
Acquaintances: 
PrimaryOccupation: Oil Trader
PrimaryOccupationCategory: Merchant
Occupation:
    - Oil Trader 
Importance: 4
SpouseName: Riley(Husband)
SpouseAge: Young Adult 
SpouseGender: Male
SpouseCondition: Sick 
Parents: 
    - Haley(Mother) Elderly  Female who is Fit as a fiddle 
    - Astley(Father) Elderly  Male who is Fit 
Children: 
    No Children
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Funny  
SocialTrait:
- Loyal  
MentalTrait:
- Superstitious  
- Incompetent  
PersonalGoals: Conquer their fear. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[humanBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

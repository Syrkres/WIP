---
fileType: npc
Art: halfbreedBanner01.png
Name: Reed
Surname: Friend
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Elf
Alignment: chaotic
Gender: Female
Sexuality: Bisexual 
Appearance: Tall athletic build, with white eyes and thinning white hair. Their face has small scar and their speech is slow 
Age: Adult 
Condition: Fine 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Apple 
    - Drama 
    - Gossip 
    - Cleaning 
Dislikes: 
    - Getting lost 
    - Volunteering 
    - Orange 
    - Being early 
Acquaintances: 
PrimaryOccupation: Laundress
PrimaryOccupationCategory: Laborer
Occupation:
    - Laundress 
Importance: 4
SpouseName: Ainsworth(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Dying 
Parents: 
    - Hallewell(Mother) Elderly  Female who is Deceased
    - Digby(Father) Elderly  Male who is Deceased
Children: 
    - Bradly(Child) Child  Girl who is Sick  
    - Cotton(Child) Teen  Boy who is Fine  
    - Colton(Child) Child  Girl who is Healthy as a horse  
AssociatedGroup:
    - Union 
AssociatedReligion:
PersonalityTrait:
- Naive  
SocialTrait:
- Unfair  
- Unfriendly  
MentalTrait:
- Adaptive  
- Indecisive  
- Uninventive  
PersonalGoals: Avoid failure. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

---
fileType: npc
Art: unknownBanner01.png
Name: Sutherland
Surname: Lujan
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Deep Gnome
Alignment: chaotic
Gender: Male
Sexuality: Bisexual 
Appearance: Tall fat build, with brown eyes and well groomed auburn hair. Their face has large scar and their speech is husky 
Age: Ancient 
Condition: Well 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Rivers 
    - Showers / baths 
Dislikes: 
    - Apple 
    - Getting lost 
    - Forests 
    - Witchcraft 
Acquaintances: 
PrimaryOccupation: Kettle Maker
PrimaryOccupationCategory: Craftsman
Occupation:
    - Kettle Maker 
Importance: 7
SpouseName: Royston(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Sick 
Parents: 
    - Spalding(Mother) Elderly  Female who is Deceased
    - Fulton(Father) Adult  Male who is Fit as a fiddle 
Children: 
    No Children
AssociatedGroup:
    - Craftsman Guild 
AssociatedReligion:
PersonalityTrait:
- Pessimistic  
SocialTrait:
- Forthcoming  
MentalTrait:
- Intelligent  
PersonalGoals: Protect their business. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[unknownBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

---
fileType: npc
Art: halflingBanner01.png
Name: Jago
Surname: Bracehole
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Stout Halfling
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Extra tall athletic build, with green eyes and frazzled grey hair. Their face is missing teeth and their speech is crisp 
Age: Adult 
Condition: Wounded 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Art 
    - Cleaning 
Dislikes: 
    - Flower pressing 
    - Clouds 
    - Touching 
Acquaintances: 
PrimaryOccupation: Stabler
PrimaryOccupationCategory: Animal Handler
Occupation:
    - Stabler 
Importance: 4
SpouseName: Pimpernel(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Lavinia(Mother) Elderly  Female who is Incapacitaed 
    - Bucca(Father) Elderly  Male who is Fine 
Children: 
    No Children
AssociatedGroup:
    - Mages Guild 
AssociatedReligion:
PersonalityTrait:
- Overt  
- Energetic  
SocialTrait:
- Lenient  
- Violent  
- Dependable  
MentalTrait:
- Reckless  
PersonalGoals: Become powerful. 
WhichParty: 
Party1Standing: 
---

---
fileType: npc
Art: elvenBanner01.png
Name: Eletha
Surname: Erwuathem
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Male
Sexuality: Bisexual 
Appearance: Normal fat build, with brown eyes and thick brown hair. Their face is grizzled and their speech is whiny 
Age: Adult 
Condition: Healthy 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Cooking 
    - Rain 
    - Mountains 
    - Fitted clothing 
Dislikes: 
    - Eldritch monsters 
    - Money 
    - Hiking 
    - Competition 
Acquaintances: 
PrimaryOccupation: Thief
PrimaryOccupationCategory: Criminal
Occupation:
    - Thief 
Importance: 1
SpouseName: Thatoryl(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Hurt 
Parents: 
    - Aneirin(Mother) Elderly  Female who is Healthy as a horse 
    - Selgauth(Father) Adult  Male who is Inured 
Children: 
    No Children
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Listless  
- Savvy  
SocialTrait:
- Selfish  
- Tolerant  
MentalTrait:
- Cautious  
PersonalGoals: Find a new creative outlet. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

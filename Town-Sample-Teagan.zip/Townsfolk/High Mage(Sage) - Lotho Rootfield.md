---
fileType: npc
Art: halflingBanner01.png
Name: Lotho
Surname: Rootfield
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Lightfoot Halfling
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Extra tall wide build, with white eyes and messy auburn hair. Their face has a missing left eye and their speech is with lisps 
Age: Young Adult 
Condition: All Right 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Wyvern 
Dislikes: 
    - Birthdays 
    - Alchemy 
    - Lightning 
    - Forests 
Acquaintances: 
PrimaryOccupation: High Mage
PrimaryOccupationCategory: Sage
Occupation:
    - High Mage 
Importance: 11
SpouseName: Belba(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Fit as a fiddle 
Parents: 
    - Linda(Mother) Elderly  Female who is Deceased
    - Moro(Father) Elderly  Male who is Deceased
Children: 
    - Sméagol(Child) Teen  Boy who is Incapacitaed  
    - Bandobras(Child) Infant  Boy who is Hurt  
    - Eglantine(Child) Child  Girl who is All Right  
AssociatedGroup:
    - Mages Guild 
AssociatedReligion:
PersonalityTrait:
- Dull  
- Pessimistic  
SocialTrait:
- Honest  
MentalTrait:
- Emotional  
- Ambitious  
- Comformist  
PersonalGoals: Find out the fate of a friend. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

---
fileType: npc
Art: elvenBanner01.png
Name: Jhaumrithe
Surname: Malsazea
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Eladrin Elf
Alignment: chaotic
Gender: Male
Sexuality: Gay 
Appearance: Grand weak build, with blue eyes and messy auburn hair. Their face is squinty and their speech is slured 
Age: Elderly 
Condition: Sick 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Throwing rocks 
    - Dolls 
Dislikes: 
    - Learning 
    - The moon 
    - Gossip 
Acquaintances: 
PrimaryOccupation: Merc
PrimaryOccupationCategory: Merc
Occupation:
    - Merc 
Importance: 3
SpouseName: Zhoron(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Healthy 
Parents: 
    - Takari(Mother) Elderly  Female who is Wounded 
    - Xanotter(Father) Ancient  Male who is Deceased
Children: 
    - Mariona(Child) Child  Girl who is Fit  
    - Dasyra(Child) Young Adult  Girl who is Healthy  
AssociatedGroup:
    - Vanguard 
AssociatedReligion:
PersonalityTrait:
- Funny  
SocialTrait:
- Demanding  
- Forthcoming  
MentalTrait:
- Perceptive  
- Secular  
PersonalGoals: Go on an adventure. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

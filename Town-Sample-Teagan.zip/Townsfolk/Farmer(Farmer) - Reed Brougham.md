---
fileType: npc
Art: halfbreedBanner01.png
Name: Reed
Surname: Brougham
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Normal strong build, with blue eyes and short red hair. Their face has a patch over left eye and their speech is stuttered 
Age: Adult 
Condition: All Right 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Open windows 
    - Nature 
    - Farming 
    - Road trips 
Dislikes: 
    - Soap carving 
    - Cleaning 
Acquaintances: 
PrimaryOccupation: Farmer
PrimaryOccupationCategory: Farmer
Occupation:
    - Farmer 
Importance: 3
SpouseName: Lindsey(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Fit 
Parents: 
    - Graeme(Mother) Ancient  Female who is Healthy 
    - Springfield(Father) Adult  Male who is Fit 
Children: 
    - Alton(Child) Infant  Girl who is Healthy  
AssociatedGroup:
    - Mages Guild 
AssociatedReligion:
PersonalityTrait:
- Impolite  
- Eccentric  
SocialTrait:
- Selfless  
- Intolerant  
- Secretive  
MentalTrait:
- Skeptical  
PersonalGoals: Be the best they can be. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

---
fileType: npc
Art: elvenBanner01.png
Name: Aneirin
Surname: Auvrealylth
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Star Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Extra short fat build, with red eyes and thinning grey hair. Their face has a broken nose and their speech is breathless 
Age: Adult 
Condition: Scraped up 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Knick-knacks 
    - Weapons 
    - Sailing 
    - Competition 
Dislikes: 
    - Urban exploring 
    - Orange 
    - Getting lost 
    - Gossip 
Acquaintances: 
PrimaryOccupation: Horse Trader
PrimaryOccupationCategory: Merchant
Occupation:
    - Horse Trader 
Importance: 4
SpouseName: Pywaln(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Healthy 
Parents: 
    - Araushnee(Mother) Elderly  Female who is Deceased
    - Horith(Father) Adult  Male who is Healthy 
Children: 
    No Children
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Savvy  
- Humorless  
SocialTrait:
- Violent  
- Unfaithful  
MentalTrait:
- Indecisive  
PersonalGoals: Be strong. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

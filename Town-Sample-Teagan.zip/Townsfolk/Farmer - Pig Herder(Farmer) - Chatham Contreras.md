---
fileType: npc
Art: halfbreedBanner01.png
Name: Chatham
Surname: Contreras
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Elf
Alignment: chaotic
Gender: Male
Sexuality: Bisexual 
Appearance: Normal athletic build, with red eyes and straight brown hair. Their face has a goatee and their speech is loud 
Age: Adult 
Condition: Healthy 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Treasure hunting 
    - Comfortable silence 
    - Witchcraft 
    - Certain people 
Dislikes: 
    - Fairy tales 
Acquaintances: 
PrimaryOccupation: Farmer - Pig Herder
PrimaryOccupationCategory: Farmer
Occupation:
    - Farmer - Pig Herder 
Importance: 3
SpouseName: Hornsby(Wife)
SpouseAge: Young Adult 
SpouseGender: Female
SpouseCondition: Well 
Parents: 
    - Middleton(Mother) Ancient  Female who is Deceased
    - Asheton(Father) Elderly  Male who is Fit 
Children: 
    - Perry(Child) Young Adult  Girl who is Dead  
    - Langley(Child) Teen  Girl who is Not oneself  
    - Acton(Child) Child  Boy who is Fit  
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Polite  
- Eccentric  
SocialTrait:
- Friendly  
- Unreliable  
- Bossy  
MentalTrait:
- Superstitious  
PersonalGoals: Remain hidden. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

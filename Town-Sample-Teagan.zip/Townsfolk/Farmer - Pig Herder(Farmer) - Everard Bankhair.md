---
fileType: npc
Art: halflingBanner01.png
Name: Everard
Surname: Bankhair
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Ghostwise Halfling
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Tall wide build, with blue eyes and limp grey hair. Their face has a broken nose and their speech is slow 
Age: Mature Adult 
Condition: Healthy 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Puzzles 
    - Parades 
    - The moon 
    - Falling leaves 
Dislikes: 
    - Shopping 
    - Hiking 
Acquaintances: 
PrimaryOccupation: Farmer - Pig Herder
PrimaryOccupationCategory: Farmer
Occupation:
    - Farmer - Pig Herder 
Importance: 3
SpouseName: Rosa(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Fine 
Parents: 
    - Gerda(Mother) Elderly  Female who is Nauseos 
    - Dudo(Father) Adult  Male who is Sick 
Children: 
    - Fastred(Child) Teen  Boy who is Not oneself  
    - Cora(Child) Young Adult  Girl who is Healthy  
AssociatedGroup:
    - Mages Guild 
AssociatedReligion:
PersonalityTrait:
- Energetic  
- Energetic  
SocialTrait:
- Secretive  
- Secretive  
MentalTrait:
- Secular  
- Adaptive  
PersonalGoals: Do the impossible. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

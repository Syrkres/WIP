---
fileType: npc
Art: humanBanner01.png
Name: Cromwell
Surname: Gosden
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Human
Alignment: chaotic
Gender: Male
Sexuality: Asexual 
Appearance: Squat strong build, with red eyes and dreadlocks white hair. Their face has large ears and their speech is with lisps 
Age: Adult 
Condition: Fit 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Facial hair 
    - Facial hair 
    - Soap carving 
    - The ocean 
Dislikes: 
    - Jumping in puddles 
Acquaintances: 
PrimaryOccupation: Stabler
PrimaryOccupationCategory: Animal Handler
Occupation:
    - Stabler 
Importance: 4
SpouseName: Alton(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Hurt 
Parents: 
    - Enfield(Mother) Elderly  Female who is Inured 
    - Tyndall(Father) Elderly  Male who is Healthy 
Children: 
    - Dudley(Child) Child  Girl who is Healthy  
    - Yeardley(Child) Child  Girl who is Healthy  
    - Wakefield(Child) Infant  Boy who is Ailing  
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Impolite  
SocialTrait:
- Talkative  
- Secretive  
- Demanding  
MentalTrait:
- Complacent  
- Indecisive  
- Secular  
PersonalGoals: Be the best they can be. 
WhichParty: 
Party1Standing: 
---

---
fileType: npc
Art: halflingBanner01.png
Name: Bingo
Surname: Longweed
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Stout Halfling
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Extra tall frail build, with red eyes and straight black hair. Their face has small scar on left cheek and their speech is slured 
Age: Adult 
Condition: Healthy 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Searching for lost items 
    - Being early 
Dislikes: 
    - Staying inside 
    - Buttons 
Acquaintances: 
PrimaryOccupation: Furniture Maker
PrimaryOccupationCategory: Artisan
Occupation:
    - Furniture Maker 
Importance: 4
SpouseName: Poppy(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Unwell 
Parents: 
    - Camelia(Mother) Elderly  Female who is Deceased
    - Isengrim(Father) Elderly  Male who is Deceased
Children: 
    No Children
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Listless  
SocialTrait:
- Friendly  
- Unfriendly  
MentalTrait:
- Decisive  
- Impatient  
PersonalGoals: Restart the world. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

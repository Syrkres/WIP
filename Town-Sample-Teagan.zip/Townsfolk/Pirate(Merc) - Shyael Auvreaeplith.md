---
fileType: npc
Art: elvenBanner01.png
Name: Shyael
Surname: Auvreaeplith
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Wood Elf
Alignment: chaotic
Gender: Female
Sexuality: Bisexual 
Appearance: Grand weak build, with red eyes and very long black hair. Their face has large scar on left cheek and their speech is accented 
Age: Adult 
Condition: Fit 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Insects 
Dislikes: 
    - Flower pressing 
    - Seashells 
    - Shopping 
    - Money 
Acquaintances: 
PrimaryOccupation: Pirate
PrimaryOccupationCategory: Merc
Occupation:
    - Pirate 
Importance: 1
SpouseName: Zaos(Husband)
SpouseAge: Elderly 
SpouseGender: Male
SpouseCondition: Impaired 
Parents: 
    - Araushnee(Mother) Ancient  Female who is Healthy 
    - Aelrindel(Father) Elderly  Male who is Fine 
Children: 
    - Riluaneth(Child) Child  Boy who is Not oneself  
    - Yalanilue(Child) Young Adult  Girl who is Healthy  
AssociatedGroup:
    - Mercenary Guild 
AssociatedReligion:
PersonalityTrait:
- Depressed  
- Respectful  
SocialTrait:
- Dishonest  
- Lenient  
- Generous  
MentalTrait:
- Impatient  
PersonalGoals: Find beauty. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

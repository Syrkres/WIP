---
fileType: npc
Art: elvenBanner01.png
Name: Synnorha
Surname: Badenvavalsa
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Tall strong build, with blue eyes and dreadlocks grey hair. Their face is pierced and their speech is wheezy 
Age: Adult 
Condition: Fit 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Learning 
    - Art 
    - Dolls 
    - Lockpicking 
Dislikes: 
    - Abandoned buildings 
    - The stars 
    - Sword 
Acquaintances: 
PrimaryOccupation: Farmer - Goat Herder
PrimaryOccupationCategory: Farmer
Occupation:
    - Farmer - Goat Herder 
Importance: 3
SpouseName: Kuskyn(Husband)
SpouseAge: Mature Adult 
SpouseGender: Male
SpouseCondition: Not oneself 
Parents: 
    - Eallyrl(Mother) Elderly  Female who is Fit 
    - Ryul(Father) Elderly  Male who is Ill 
Children: 
    - Symrustar(Child) Young Adult  Girl who is Expired  
AssociatedGroup:
    - Mages Guild 
AssociatedReligion:
PersonalityTrait:
- Subtle  
- Eccentric  
SocialTrait:
- Selfless  
- Friendly  
MentalTrait:
- Perceptive  
PersonalGoals: Reach the promised lands. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

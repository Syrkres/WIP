---
fileType: npc
Art: planerBanner01.png
Name: Stanley
Surname: Tunnicliffe
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Scourge Aasimar
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Grand strong build, with hazel eyes and well groomed grey hair. Their face is chiseled and their speech is whiny 
Age: Adult 
Condition: All Right 
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
    - Loud noises 
    - Being early 
    - Children 
Dislikes: 
    - Fitted clothing 
    - Shopping 
    - Drama 
Acquaintances: 
PrimaryOccupation: Town Justice
PrimaryOccupationCategory: Elected Official
Occupation:
    - Town Justice 
Importance: 10
SpouseName: Shirley(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: All Right 
Parents: 
    - Kirby(Mother) Elderly  Female who is Fine 
    - Fawcett(Father) Ancient  Male who is Fit 
Children: 
    - Wilberforce(Child) Young Adult  Boy who is Unwell  
AssociatedGroup:
    - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Funny  
SocialTrait:
- Lenient  
MentalTrait:
- Impatient  
- Cautious  
PersonalGoals: Become powerful. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[planerBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes

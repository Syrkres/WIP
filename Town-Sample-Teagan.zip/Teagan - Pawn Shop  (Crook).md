---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Pawn Shop 
ownerName: Alton Bruce 
ownerLink: "[[Crook(Criminal) - Alton Bruce|Alton Bruce]]"
ownerRace: Gavony Human
apprentices: 
- Stanley (Teen ) Male who is Healthy  
- Browning (Adult ) Female who is Well  
services: 
- Criminal( Horrible   quality, High  costs) 
- Deception( Horrible   quality, Low  costs) 
- Theft( Average   quality, Average  costs) 
exterior: An narrow building with shingled siding with a front broken window that has a carved sign hanging to the side with the merchants name. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


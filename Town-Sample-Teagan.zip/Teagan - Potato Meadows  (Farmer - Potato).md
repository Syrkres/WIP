---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Potato Meadows 
ownerName: Stanton Mcqueen 
ownerLink: "[[Farmer - Potato(Farmer) - Stanton Mcqueen|Stanton Mcqueen]]"
ownerRace: Half-Orc
apprentices: 
- Acton (Teen ) Male who is Fit  
- Byron (Adult ) Female who is Nauseos  
services: 
- Farmer( Low   quality, Below Average  costs) 
- Food( Average   quality, Average  costs) 
exterior: An building with faded paint and with brick siding with a few round windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Water Carrier 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Water Porter 
ownerName: Altham Furze 
ownerLink: "[[Water Carrier(Laborer) - Altham Furze|Altham Furze]]"
ownerRace: Changeling
apprentices: 
- No apprentices
services: 
- Laborer( Average   quality, Below Average  costs) 
- Water Carrier( Horrible   quality, Low  costs) 
exterior: An new building with new paint and with planked siding. The roof is Roof. A Ceder pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


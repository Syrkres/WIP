---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Maidservant Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Well Clean for you 
ownerName: Riluaneth Opulumannia 
ownerLink: "[[Maidservant(Laborer) - Riluaneth Opulumannia|Riluaneth Opulumannia]]"
ownerRace: High  Elf
apprentices: 
- Deighton (Teen ) Male who is Healthy  
- Morley (Young Adult ) Male who is Healthy  
services: 
- Laborer( Horrible   quality, Average  costs) 
- Maid( Low   quality, Average  costs) 
- Cleaning( Excellent   quality, High  costs) 
exterior: An old tall building with shingled siding. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


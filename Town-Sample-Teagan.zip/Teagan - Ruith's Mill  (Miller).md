---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller 
merchantCategory: Cook
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ruith's Mill 
ownerName: Ruith Hollyathem 
ownerLink: "[[Miller(Cook) - Ruith Hollyathem|Ruith Hollyathem]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Miller( Excellent   quality, Above Average  costs) 
- Harvester( Excellent   quality, Below Average  costs) 
exterior: An old long tall building with shingled siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


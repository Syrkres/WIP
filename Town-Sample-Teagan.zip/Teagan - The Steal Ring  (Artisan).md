---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Jeweler Artisan
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Steal Ring 
ownerName: Jo Sackgirdle 
ownerLink: "[[Jeweler(Artisan) - Jo Sackgirdle|Jo Sackgirdle]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Asheton (Young Adult ) Male who is Healthy  
- Cumberbatch (Adult ) Male who is Healthy  
services: 
- Jewelery Crafting( Poor   quality, High  costs) 
- Craft( Good   quality, Average  costs) 
- Gem Cutting( Horrible   quality, Low  costs) 
exterior: An building with planked siding. The roof is House. A Maple shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


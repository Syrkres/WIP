---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Chubby Boar Farm 
ownerName: Bingo Fairfurrow 
ownerLink: "[[Farmer - Pig Herder(Farmer) - Bingo Fairfurrow|Bingo Fairfurrow]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Huxley (Child ) Female who is Well  
- Dryden (Young Adult ) Male who is Fit  
services: 
- Farmer( Excellent   quality, Below Average  costs) 
- Food( Poor   quality, Low  costs) 
- Herding( Low   quality, Average  costs) 
exterior: An old building with shingled siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


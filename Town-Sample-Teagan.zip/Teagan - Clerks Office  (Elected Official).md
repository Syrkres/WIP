---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clerk Elected Official
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,CLERK
title: Clerks Office 
ownerName: Ashton Carroll 
ownerLink: "[[Clerk(Elected Official) - Ashton Carroll|Ashton Carroll]]"
ownerRace: Human
apprentices: 
- Windsor (Teen ) Female who is Scraped up  
- Nibley (Young Adult ) Male who is Healthy  
services: 
- Elected Official( Good   quality, Below Average  costs) 
- Diplomacy( Excellent   quality, Low  costs) 
- Note Taking( Excellent   quality, Below Average  costs) 
exterior: An new narrow building with faded paint and with planked siding with a front boarded window that has a painted sign hanging above with the merchants name. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


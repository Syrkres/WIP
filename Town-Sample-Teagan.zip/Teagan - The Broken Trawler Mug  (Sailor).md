---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sailor 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Broken Trawler Mug 
ownerName: Rowley Chavez 
ownerLink: "[[Sailor(Merc) - Rowley Chavez|Rowley Chavez]]"
ownerRace: Human
apprentices: 
- No apprentices
services: 
- Mercenary( Excellent   quality, Average  costs) 
- Sailor( Excellent   quality, Above Average  costs) 
- Thug( Low   quality, Average  costs) 
exterior: An old two story building with faded paint and with stoned siding with a missing window. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Order Guild 
ownerName: Remington Hill 
ownerLink: "[[Teamster(Laborer) - Remington Hill|Remington Hill]]"
ownerRace: Half-Elf
apprentices: 
- No apprentices
services: 
- Laborer( Poor   quality, Below Average  costs) 
- Teamster( Excellent   quality, High  costs) 
exterior: An building with faded paint and with brick siding. The roof is Celing. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


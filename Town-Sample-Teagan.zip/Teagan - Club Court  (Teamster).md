---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Club Court 
ownerName: Ketum Rumnaheim 
ownerLink: "[[Teamster(Laborer) - Ketum Rumnaheim|Ketum Rumnaheim]]"
ownerRace: Hill Dwarf
apprentices: 
- York (Young Adult ) Male who is All Right  
services: 
- Laborer( Good   quality, Above Average  costs) 
- Teamster( Poor   quality, Above Average  costs) 
exterior: An two story building with stoned siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A Pine shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


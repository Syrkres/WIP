---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe 
merchantCategory: Professional Specialties
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,ALCHEMIST
title: Scribes Shop 
ownerName: Iago Proudbairn 
ownerLink: "[[Scribe(Professional Specialties) - Iago Proudbairn|Iago Proudbairn]]"
ownerRace: Lightfoot Halfling
apprentices: 
- Huckabee (Adult ) Male who is Unwell  
services: 
- Research( Average   quality, Low  costs) 
- Scribe( Low   quality, High  costs) 
exterior: An old building with new paint and with brick siding. The roof is House. A Ceder shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


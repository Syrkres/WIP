---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Sheep Herder Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Twilight dagger Nursery 
ownerName: Emsworth Glass 
ownerLink: "[[Farmer - Sheep Herder(Farmer) - Emsworth Glass|Emsworth Glass]]"
ownerRace: Half-Orc
apprentices: 
- Browning (Adult ) Female who is Incapacitaed  
services: 
- Farmer( Average   quality, High  costs) 
- Food( Low   quality, Above Average  costs) 
- Herding( Good   quality, Above Average  costs) 
exterior: An tall building with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Shoe Maker Garment Trade
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Shoe Peddler 
ownerName: Sancho Whitrogers 
ownerLink: "[[Shoe Maker(Garment Trade) - Sancho Whitrogers|Sancho Whitrogers]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Alston (Young Adult ) Female who is Fit  
services: 
- Garment Trade( Average   quality, Low  costs) 
- Shoe Maker( Average   quality, Below Average  costs) 
exterior: An narrow two story building with stoned siding with a missing window. The roof is Dome. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


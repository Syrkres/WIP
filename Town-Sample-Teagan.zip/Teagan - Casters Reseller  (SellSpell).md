---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: SellSpell 
merchantCategory: Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,ALCHEMIST
title: Casters Reseller 
ownerName: Mitchell Munson 
ownerLink: "[[SellSpell(Sage) - Mitchell Munson|Mitchell Munson]]"
ownerRace: Protector Aasimar
apprentices: 
- Appleton (Adult ) Male who is Wounded  
services: 
- Sage( Horrible   quality, Above Average  costs) 
- Spellcraft( Average   quality, Low  costs) 
- Spell Research( Excellent   quality, High  costs) 
- Spell Casting( Excellent   quality, Low  costs) 
exterior: An old building with brick siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


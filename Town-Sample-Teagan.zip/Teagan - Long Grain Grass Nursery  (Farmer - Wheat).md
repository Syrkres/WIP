---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Long Grain Grass Nursery 
ownerName: Ardryll Hulwarvamundlin 
ownerLink: "[[Farmer - Wheat(Farmer) - Ardryll Hulwarvamundlin|Ardryll Hulwarvamundlin]]"
ownerRace: Mul Daya Nation Elf
apprentices: 
- Digby (Teen ) Female who is Dead  
- Landon (Child ) Male who is Dying  
services: 
- Farmer( Excellent   quality, Above Average  costs) 
- Food( Low   quality, Low  costs) 
exterior: An old tall building with new paint and with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


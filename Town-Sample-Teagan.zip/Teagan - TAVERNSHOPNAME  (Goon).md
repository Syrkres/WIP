---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Goon 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: TAVERNSHOPNAME 
ownerName: Hayden Gibson 
ownerLink: "[[Goon(Criminal) - Hayden Gibson|Hayden Gibson]]"
ownerRace: Nephalia Human
apprentices: 
- Bradford (Adult ) Male who is All Right  
services: 
- Criminal( Horrible   quality, Average  costs) 
- Deception( Horrible   quality, Below Average  costs) 
- Enforcement( Excellent   quality, Above Average  costs) 
- Guarding( Average   quality, Average  costs) 
exterior: An narrow tall building with new paint and with stoned siding with a missing short window. The roof is Roof. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


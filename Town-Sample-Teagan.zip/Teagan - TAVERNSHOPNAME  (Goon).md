---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Goon 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: TAVERNSHOPNAME 
ownerName: Winterbourne Billings 
ownerLink: "[[Goon(Criminal) - Winterbourne Billings|Winterbourne Billings]]"
ownerRace: Human
apprentices: 
- No apprentices
services: 
- Criminal( Good   quality, Low  costs) 
- Deception( Average   quality, Below Average  costs) 
- Enforcement( Good   quality, Average  costs) 
- Guarding( Low   quality, Below Average  costs) 
exterior: An new one story building with shingled siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


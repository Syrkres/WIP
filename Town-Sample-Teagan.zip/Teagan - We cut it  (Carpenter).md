---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Carpenter 
merchantCategory: Construction
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: We cut it 
ownerName: Talaedra Tukwoderrae 
ownerLink: "[[Carpenter(Construction) - Talaedra Tukwoderrae|Talaedra Tukwoderrae]]"
ownerRace: Mul Daya Nation Elf
apprentices: 
- Harrington (Young Adult ) Female who is All Right  
services: 
- Construction( Excellent   quality, Below Average  costs) 
- Crafting( Excellent   quality, High  costs) 
exterior: An building with planked siding with a missing window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


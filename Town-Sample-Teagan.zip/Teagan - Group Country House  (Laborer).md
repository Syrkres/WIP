---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Group Country House 
ownerName: Alton Stokes 
ownerLink: "[[Teamster(Laborer) - Alton Stokes|Alton Stokes]]"
ownerRace: Half-Orc
apprentices: 
- Barton (Teen ) Male who is Unwell  
- Barclay (Young Adult ) Male who is Unwell  
services: 
- Laborer( Low   quality, Low  costs) 
- Teamster( Poor   quality, Below Average  costs) 
exterior: An long one story building with faded paint and with planked siding with a missing window. The roof is Dome. A Yellow Birch shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Carpenter Construction
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: We cut it 
ownerName: Harding Chetfoot 
ownerLink: "[[Carpenter(Construction) - Harding Chetfoot|Harding Chetfoot]]"
ownerRace: Stout Halfling
apprentices: 
- Brandon (Young Adult ) Female who is Dying  
- Cromwell (Young Adult ) Male who is Healthy  
services: 
- Construction( Excellent   quality, Above Average  costs) 
- Crafting( Low   quality, Average  costs) 
exterior: An two story building with faded paint and with planked siding with a missing round window. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


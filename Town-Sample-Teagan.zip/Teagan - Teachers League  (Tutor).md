---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor 
merchantCategory: Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Teachers League 
ownerName: Winthrop Pegg 
ownerLink: "[[Tutor(Sage) - Winthrop Pegg|Winthrop Pegg]]"
ownerRace: Half-Elf
apprentices: 
- No apprentices
services: 
- Sage( Excellent   quality, Low  costs) 
- Teaching( Poor   quality, High  costs) 
- Research( Excellent   quality, Below Average  costs) 
exterior: An long building with new paint and with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


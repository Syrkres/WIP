---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor 
merchantCategory: Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Teachers League 
ownerName: Huckabee Richter 
ownerLink: "[[Tutor(Sage) - Huckabee Richter|Huckabee Richter]]"
ownerRace: Vedalken
apprentices: 
- Wesley (Young Adult ) Female who is Dying  
services: 
- Sage( Good   quality, Above Average  costs) 
- Teaching( Excellent   quality, High  costs) 
- Research( Average   quality, Below Average  costs) 
exterior: An new building with planked siding with a few broken windows. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Aged Elm Farm 
ownerName: Reed Brougham 
ownerLink: "[[Farmer(Farmer) - Reed Brougham|Reed Brougham]]"
ownerRace: Half-Elf
apprentices: 
- Fawcett (Young Adult ) Female who is Healthy as a horse  
- Barlow (Teen ) Female who is Healthy  
services: 
- Farmer( Average   quality, Average  costs) 
- Food( Low   quality, Average  costs) 
exterior: An new one story building with stoned siding with a missing short window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


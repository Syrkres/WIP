---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Pawn Reseller 
ownerName: Eglantine Fareward 
ownerLink: "[[Crook(Criminal) - Eglantine Fareward|Eglantine Fareward]]"
ownerRace: Stout Halfling
apprentices: 
- No apprentices
services: 
- Criminal( Horrible   quality, Below Average  costs) 
- Deception( Horrible   quality, Low  costs) 
- Theft( Good   quality, Low  costs) 
exterior: An narrow building with new paint and with stoned siding. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: Club Hall 
ownerName: Elaethan Kennyrsithek 
ownerLink: "[[Merc(Merc) - Elaethan Kennyrsithek|Elaethan Kennyrsithek]]"
ownerRace: Wood Elf
apprentices: 
- Sheldon (Teen ) Female who is Fine  
services: 
- Mercenary( Low   quality, Average  costs) 
- Intimidation( Poor   quality, Low  costs) 
- Guarding( Horrible   quality, Average  costs) 
exterior: An building with planked siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


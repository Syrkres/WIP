---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pirate Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Ye Rusted Cutlass 
ownerName: Laura Chetburrow 
ownerLink: "[[Pirate(Merc) - Laura Chetburrow|Laura Chetburrow]]"
ownerRace: Stout Halfling
apprentices: 
- Allerton (Teen ) Female who is Fit  
- Springfield (Adult ) Female who is Hurt  
services: 
- Mercenary( Poor   quality, Low  costs) 
- Intimidation( Good   quality, High  costs) 
- Shipping( Poor   quality, Above Average  costs) 
- Guarding( Horrible   quality, Low  costs) 
exterior: An building with faded paint and with shingled siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


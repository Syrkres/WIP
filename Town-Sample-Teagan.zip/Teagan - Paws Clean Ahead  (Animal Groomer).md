---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer 
merchantCategory: Animal Handler
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: TANNERY,FARM,STABLE
title: Paws Clean Ahead 
ownerName: Hailey Hesketh 
ownerLink: "[[Animal Groomer(Animal Handler) - Hailey Hesketh|Hailey Hesketh]]"
ownerRace: Stensia Human
apprentices: 
- No apprentices
services: 
- Animal Handler( Good   quality, Average  costs) 
- Pet Training( Good   quality, Low  costs) 
- Animal Training( Low   quality, Average  costs) 
exterior: An tall building with planked siding. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Sheep Herder Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: The Wooly Sheep Nursery 
ownerName: Isilfarrel Wobanmitore 
ownerLink: "[[Farmer - Sheep Herder(Farmer) - Isilfarrel Wobanmitore|Isilfarrel Wobanmitore]]"
ownerRace: Elf
apprentices: 
- Deighton (Adult ) Female who is All Right  
- Charlton (Teen ) Male who is Expired  
services: 
- Farmer( Low   quality, Above Average  costs) 
- Food( Poor   quality, Below Average  costs) 
- Herding( Good   quality, High  costs) 
exterior: An narrow tall building with faded paint and with shingled siding with a front tall window that has a painted sign hanging above with the merchants name. The roof is Celing. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


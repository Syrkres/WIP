---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mountainman 
merchantCategory: Tracker
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Outdoor Store 
ownerName: Storur Dankil 
ownerLink: "[[Mountainman(Tracker) - Storur Dankil|Storur Dankil]]"
ownerRace: Hill Dwarf
apprentices: 
- Ryley (Mature Adult ) Female who is Healthy  
- Trollope (Teen ) Female who is Ill  
services: 
- Tracker( Low   quality, High  costs) 
- Hunting( Horrible   quality, Below Average  costs) 
exterior: An old two story building with stoned siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


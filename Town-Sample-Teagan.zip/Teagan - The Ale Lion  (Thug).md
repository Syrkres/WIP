---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thug 
merchantCategory: Criminal
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Ale Lion 
ownerName: Mantissa Mughome 
ownerLink: "[[Thug(Criminal) - Mantissa Mughome|Mantissa Mughome]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Blackwood (Young Adult ) Male who is Maimed  
- Stanford (Mature Adult ) Female who is Impaired  
services: 
- Criminal( Horrible   quality, Average  costs) 
- Deception( Horrible   quality, Average  costs) 
- Guarding( Horrible   quality, High  costs) 
exterior: An narrow building with brick siding with a missing round window. The roof is Roof. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


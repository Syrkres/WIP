---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dungsweeper 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: We Pick it up 
ownerName: Vhoorhin Parantghymn 
ownerLink: "[[Dungsweeper(Laborer) - Vhoorhin Parantghymn|Vhoorhin Parantghymn]]"
ownerRace: High  Elf
apprentices: 
- Clare (Young Adult ) Female who is Ailing  
services: 
- Laborer( Poor   quality, Below Average  costs) 
exterior: An old narrow building with faded paint and with shingled siding with a few broken windows. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


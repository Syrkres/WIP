---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dungsweeper 
merchantCategory: Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: We Pick it up 
ownerName: Landon Steiner 
ownerLink: "[[Dungsweeper(Laborer) - Landon Steiner|Landon Steiner]]"
ownerRace: Fallen Aasimar
apprentices: 
- No apprentices
services: 
- Laborer( Horrible   quality, Low  costs) 
exterior: An new tall building with brick siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


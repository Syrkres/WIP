---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Candle Maker Specialty Service
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Taper 
ownerName: Fulton Lugo 
ownerLink: "[[Candle Maker(Specialty Service) - Fulton Lugo|Fulton Lugo]]"
ownerRace: Half-Orc
apprentices: 
- Ashley (Teen ) Male who is All Right  
- Churchill (Young Adult ) Male who is Dying  
services: 
- Specialty Service( Horrible   quality, Above Average  costs) 
- Candle Making( Poor   quality, Low  costs) 
exterior: An old building with new paint and with planked siding with a few shuttered windows. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Mage 
merchantCategory: Sage
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,ALCHEMIST
title: Mage Tower 
ownerName: Sa�lihn Torersithek 
ownerLink: "[[High Mage(Sage) - Sa�lihn Torersithek|Sa�lihn Torersithek]]"
ownerRace: Wood Elf
apprentices: 
- Upton (Adult ) Male who is Sick  
services: 
- Sage( Low   quality, Average  costs) 
- Scroll Crafting( Average   quality, Average  costs) 
- Potion Crafting( Low   quality, Above Average  costs) 
- Spell Research( Horrible   quality, High  costs) 
exterior: An two story building with new paint and with stoned siding with a missing window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


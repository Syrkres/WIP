---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sail Maker 
merchantCategory: Craftsman
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Sail Patcher 
ownerName: Pickering Buckner 
ownerLink: "[[Sail Maker(Craftsman) - Pickering Buckner|Pickering Buckner]]"
ownerRace: Human
apprentices: 
- Cumberbatch (Teen ) Female who is Healthy  
- Oakes (Young Adult ) Female who is Scraped up  
services: 
- Craftsman( Good   quality, Average  costs) 
- Sail Maker( Horrible   quality, Above Average  costs) 
exterior: An new long building with shingled siding with a missing window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


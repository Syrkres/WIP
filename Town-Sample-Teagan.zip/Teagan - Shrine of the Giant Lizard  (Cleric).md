---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: Shrine of the Giant Lizard 
ownerName: Roanmara Tinvihamzea 
ownerLink: "[[Cleric(Clergy) - Roanmara Tinvihamzea|Roanmara Tinvihamzea]]"
ownerRace: Mul Daya Nation Elf
apprentices: 
- Carlton (Teen ) Female who is Sick  
services: 
- Clergy( Excellent   quality, Above Average  costs) 
- Religion( Average   quality, Average  costs) 
- House of Worship( Poor   quality, Above Average  costs) 
- Curse Removal( Average   quality, Average  costs) 
- Spell Research( Good   quality, Average  costs) 
- Healing( Average   quality, High  costs) 
- Potions( Horrible   quality, Average  costs) 
exterior: An two story building with faded paint and with shingled siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


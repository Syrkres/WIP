---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Dreamers star Meadows 
ownerName: Jemima Tookfield 
ownerLink: "[[Farmer(Farmer) - Jemima Tookfield|Jemima Tookfield]]"
ownerRace: Stout Halfling
apprentices: 
- Bradley (Young Adult ) Female who is Healthy  
services: 
- Farmer( Average   quality, Above Average  costs) 
- Food( Horrible   quality, Average  costs) 
exterior: An old long building with brick siding with a few tall windows. The roof is Dome. A Ceder pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


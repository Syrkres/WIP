---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn 
merchantCategory: Farmer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: FARM,HOUSE
title: Ye Tall Maize Range 
ownerName: Shelby Drew 
ownerLink: "[[Farmer - Corn(Farmer) - Shelby Drew|Shelby Drew]]"
ownerRace: Kor
apprentices: 
- Langdon (Young Adult ) Male who is Ailing  
- Norton (Adult ) Male who is Healthy  
services: 
- Farmer( Low   quality, Low  costs) 
- Food( Excellent   quality, Above Average  costs) 
exterior: An one story building with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sail Maker Craftsman
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Sail Patcher 
ownerName: Bob Braceman 
ownerLink: "[[Sail Maker(Craftsman) - Bob Braceman|Bob Braceman]]"
ownerRace: Ghostwise Halfling
apprentices: 
- No apprentices
services: 
- Craftsman( Excellent   quality, Low  costs) 
- Sail Maker( Average   quality, Above Average  costs) 
exterior: An old building with planked siding. The roof is Celing. A Maple pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


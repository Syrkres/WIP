---
cssclass: oRPGPage
fileType: settlement
settlementType: Town
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
terrain: Forest Heavy Boreal 
settlementDescription: 
population: 602
culture: Persian 
technology: Bronze Age 
leader: 
govermentType: Federation 
demographics: 
- Jeweler(1) 
- Furniture Maker(2) 
- Cleric(2) 
- High Priest(2) 
- Missionary(2) 
- Preacher(2) 
- Priest(2) 
- Carpenter(1) 
- Mason(1) 
- Painter(Building)(2) 
- Kettle Maker(2) 
- Potter(1) 
- Sail Maker(2) 
- Crime Lord(2) 
- Crook(2) 
- Goon(2) 
- Thief(2) 
- Thug(2) 
- Clerk(2) 
- Council Member(2) 
- Elected Official(2) 
- Mayor(2) 
- Town Justice(2) 
- Conjourer(1) 
- Juggler(1) 
- Troubadours(1) 
- Miller(1) 
- Furrier(1) 
- Hat Maker(1) 
- Cobbler(1) 
- Shoe Maker(1) 
- Tailor(1) 
- Used Garment Trader(1) 
- Weaver(1) 
- Guard(1) 
- Taverner(1) 
- Brothel Keeper(1) 
- Knight(1) 
- Squire(1) 
- Dungsweeper(1) 
- Laborer(1) 
- Laundress(1) 
- Maidservant(1) 
- Messenger(1) 
- Porter(1) 
- Teamster(1) 
- Water Carrier(1) 
- Barbarian(1) 
- Brigand(1) 
- Merc(1) 
- Pirate(1) 
- Sailor(1) 
- Antiquities(1) 
- Chandler(1) 
- Horse Trader(1) 
- Oil Trader(1) 
- Weapon Dealer(1) 
- Physic/Chirurgeon(1) 
- Scribe(1) 
- High Mage(1) 
- Magical Tutor(1) 
- SellSpell(1) 
- Tutor(1) 
- Barber(1) 
- Candle Maker(1) 
- Mountainman(1) 
- Scout(1) 
- Tracker(1) 
- Farmer(1) 
- Farmer - Cabbage(1) 
- Farmer - Cattle Herder(1) 
- Farmer - Corn(1) 
- Farmer - Cow Herder(1) 
- Farmer - Goat Herder(1) 
- Farmer - Pig Herder(1) 
- Farmer - Potato(1) 
- Farmer - Sheep Herder(1) 
- Farmer - Wheat(1) 
- Farmer(Special)(1) 
- Farmer - Dairy(1) 
- Animal Groomer(1) 
- Stabler(1) 
imports: 
- Malachite  
exports: 
- Salt  
defenses: Archer towers 
wards:
- 9th Ward
- Docks
- Skid Row
- Merchant District
- Market Square
---


> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`


## Notable Locations

> [!info|bg-c-purple]- Districts
`=this.wards`


> [!info|bg-c-yellow]- Demographics
`=this.demographics`

> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes




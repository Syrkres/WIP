---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Elected Official 
merchantCategory: Elected Official
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: County Clerks 
ownerName: Bellisima Chubbweed 
ownerLink: "[[Elected Official(Elected Official) - Bellisima Chubbweed|Bellisima Chubbweed]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Rowley (Adult ) Male who is Healthy  
- Stanton (Teen ) Female who is Sick  
services: 
- Elected Official( Low   quality, High  costs) 
- Diplomacy( Good   quality, Below Average  costs) 
- Clerk( Low   quality, Above Average  costs) 
- Administration( Average   quality, Above Average  costs) 
exterior: An building with faded paint and with brick siding. The roof is House. A Pine shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


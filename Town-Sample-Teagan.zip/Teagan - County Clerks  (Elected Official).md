---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Elected Official Elected Official
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: County Clerks 
ownerName: Carlyle Hartle 
ownerLink: "[[Elected Official(Elected Official) - Carlyle Hartle|Carlyle Hartle]]"
ownerRace: Human
apprentices: 
- Reed (Teen ) Male who is Sick  
services: 
- Elected Official( Low   quality, Low  costs) 
- Diplomacy( Horrible   quality, High  costs) 
- Clerk( Horrible   quality, Low  costs) 
- Administration( Excellent   quality, Above Average  costs) 
exterior: An new two story building with shingled siding. The roof is Dome. A Maple shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


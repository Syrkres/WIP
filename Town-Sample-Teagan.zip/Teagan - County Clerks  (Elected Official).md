---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Elected Official 
merchantCategory: Elected Official
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: County Clerks 
ownerName: Orlpar Ilwylwotlithar 
ownerLink: "[[Elected Official(Elected Official) - Orlpar Ilwylwotlithar|Orlpar Ilwylwotlithar]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Elected Official( Average   quality, High  costs) 
- Diplomacy( Excellent   quality, Above Average  costs) 
- Clerk( Excellent   quality, Below Average  costs) 
- Administration( Poor   quality, Below Average  costs) 
exterior: An new building with faded paint and with shingled siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


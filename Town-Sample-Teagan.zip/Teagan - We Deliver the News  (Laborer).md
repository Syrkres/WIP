---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Messenger Laborer
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: We Deliver the News 
ownerName: Afamrail Tirlomwunaear 
ownerLink: "[[Messenger(Laborer) - Afamrail Tirlomwunaear|Afamrail Tirlomwunaear]]"
ownerRace: Wood Elf
apprentices: 
- Denholm (Young Adult ) Male who is Well  
- Huckabee (Young Adult ) Female who is Deceased  
services: 
- Messenger( Excellent   quality, High  costs) 
- Transcripts( Horrible   quality, Above Average  costs) 
exterior: An new building with planked siding with a front tall window that has a carved sign hanging to the side with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


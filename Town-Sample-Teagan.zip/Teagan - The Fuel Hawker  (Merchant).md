---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader Merchant
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Fuel Hawker 
ownerName: Bradley Lynn 
ownerLink: "[[Oil Trader(Merchant) - Bradley Lynn|Bradley Lynn]]"
ownerRace: Half-Elf
apprentices: 
- Law (Young Adult ) Female who is Expired  
services: 
- Merchant( Average   quality, High  costs) 
- Oil Trader( Horrible   quality, Average  costs) 
exterior: An old one story building with new paint and with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barber Specialty Service
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: Sharp Razor 
ownerName: Hornsby Sanford 
ownerLink: "[[Barber(Specialty Service) - Hornsby Sanford|Hornsby Sanford]]"
ownerRace: Human
apprentices: 
- Carlisle (Young Adult ) Male who is Ill  
- Cholmondeley (Adult ) Female who is Fit  
services: 
- Specialty Service( Poor   quality, Above Average  costs) 
- Surgery( Excellent   quality, Low  costs) 
exterior: An new one story building with faded paint and with stoned siding with a front tall shuttered window that has a painted sign hanging above with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


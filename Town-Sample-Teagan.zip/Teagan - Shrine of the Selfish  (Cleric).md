---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: Shrine of the Selfish 
ownerName: Laura Hayman 
ownerLink: "[[Cleric(Clergy) - Laura Hayman|Laura Hayman]]"
ownerRace: Ghostwise Halfling
apprentices: 
- Churchill (Teen ) Male who is All Right  
services: 
- Clergy( Good   quality, Below Average  costs) 
- Religion( Excellent   quality, High  costs) 
- House of Worship( Average   quality, Above Average  costs) 
- Curse Removal( Good   quality, Average  costs) 
- Spell Research( Low   quality, Average  costs) 
- Healing( Horrible   quality, Above Average  costs) 
- Potions( Excellent   quality, Below Average  costs) 
exterior: An narrow building with shingled siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


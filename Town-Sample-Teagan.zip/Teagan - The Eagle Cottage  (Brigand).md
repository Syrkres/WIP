---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: JAIL,HOUSE
title: The Eagle Cottage 
ownerName: Iefyr Zaiganvalsa 
ownerLink: "[[Brigand(Merc) - Iefyr Zaiganvalsa|Iefyr Zaiganvalsa]]"
ownerRace: Bishatar/Tirahar Elf
apprentices: 
- Birkenhead (Young Adult ) Male who is Incapacitaed  
services: 
- Mercenary( Poor   quality, High  costs) 
- Enforcement( Horrible   quality, Above Average  costs) 
- Intimidation( Average   quality, Above Average  costs) 
exterior: An new one story building with faded paint and with stoned siding with a missing window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


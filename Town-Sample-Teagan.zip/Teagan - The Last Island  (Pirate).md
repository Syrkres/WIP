---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pirate 
merchantCategory: Merc
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHOP,HOUSE
title: The Last Island 
ownerName: Shyael Auvreaeplith 
ownerLink: "[[Pirate(Merc) - Shyael Auvreaeplith|Shyael Auvreaeplith]]"
ownerRace: Wood Elf
apprentices: 
- Chester (Adult ) Female who is Healthy  
services: 
- Mercenary( Good   quality, Low  costs) 
- Intimidation( Good   quality, High  costs) 
- Shipping( Good   quality, High  costs) 
- Guarding( Horrible   quality, Below Average  costs) 
exterior: An building with new paint and with shingled siding. The roof is Celing. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


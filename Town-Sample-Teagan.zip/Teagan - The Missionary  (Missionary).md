---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Missionary 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: The Missionary 
ownerName: Ihimbraskar Devonkaltylar 
ownerLink: "[[Missionary(Clergy) - Ihimbraskar Devonkaltylar|Ihimbraskar Devonkaltylar]]"
ownerRace: Mul Daya Nation Elf
apprentices: 
- No apprentices
services: 
- Clergy( Poor   quality, Below Average  costs) 
- Religion( Low   quality, High  costs) 
- Remedies( Poor   quality, Average  costs) 
exterior: An old tall building with stoned siding with a few windows. The roof is Canopy. A Maple shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 


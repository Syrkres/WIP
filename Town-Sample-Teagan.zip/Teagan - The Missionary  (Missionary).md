---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Missionary 
merchantCategory: Clergy
kingdom: Realm of LoVara
region: Central LoVara
settlementName: Teagan
urbanArea: 
structure: SHRINE,HOUSE
title: The Missionary 
ownerName: Orym Overmareplith 
ownerLink: "[[Missionary(Clergy) - Orym Overmareplith|Orym Overmareplith]]"
ownerRace: High  Elf
apprentices: 
- Kelsey (Child ) Male who is Ill  
- Brady (Teen ) Female who is Impaired  
services: 
- Clergy( Excellent   quality, Below Average  costs) 
- Religion( Horrible   quality, Below Average  costs) 
- Remedies( Good   quality, High  costs) 
exterior: An two story building with new paint and with brick siding. The roof is Dome. A Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType`
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Animal Handler | Good |
> |Animal Training | Fair |
> |Pet Training | Good |

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>> `=this.apprentices `
>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

